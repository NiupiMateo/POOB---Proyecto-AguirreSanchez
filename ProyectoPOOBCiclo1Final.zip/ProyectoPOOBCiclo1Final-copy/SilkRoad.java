import shapes.*;
import java.util.ArrayList;

/**
 * Simulador de la Ruta de la Seda - Clase Principal
 * FUNCIONALIDADES IMPLEMENTADAS:
 * Crear una ruta de seda dada su longitud
 * Adicionar o eliminar tiendas y reabastecerlas
 * Adicionar o eliminar robots y retornarlos a posiciones iniciales
 * Mover robots por la ruta
 * Reiniciar el simulador manteniendo configuración
 * Consultar ganancias acumuladas
 * Consultar información del estado actual
 * Controlar visibilidad del simulador
 * Terminar la simulación
 * @author Camilo Aguirre- Mateo Sanchez
 * @version 28-09-2025
 */
public class SilkRoad {
    private int length; 
    private ArrayList<Store> stores; 
    private ArrayList<Robot> robots; 
    private int profit; 
    private boolean visible;
    private boolean lastOk; 

    private Rectangle profitBar; 
    private Rectangle profitBackground;
    
    private static final int CELL_SIZE = 30; //Tamaño en píxeles de cada celda en la espiral.
    private static final int CENTER_X = 150;// Coordenada X del centro de la espiral en el canvas.
    private static final int CENTER_Y = 150;// Coordenada Y del centro de la espiral en el canvas  
    private String[] colors = {"red","blue","green","yellow","magenta","black","white"};
    private int colorIndex;// Índice actual en la paleta de colores. Se incrementa con cada nuevo elemento creado.
    
    public SilkRoad() {
        length = 0;  
        stores = new ArrayList<Store>();
        robots = new ArrayList<Robot>();
        profit = 0;
        visible = true;  
        lastOk = true;
        colorIndex = 0;
    }
    
    /**
     * Crea una nueva ruta de seda con la longitud especificada.
     * Esta operación reinicia completamente el simulador:
     * - Establece nueva longitud de ruta
     * - Elimina todas las tiendas y robots existentes
     * - Resetea ganancias a 0
     * - Reinicia asignación de colores
     * @param length número de posiciones en la ruta (debe ser > 0)
     * POSTCONDICIONES:
     * - Si length > 0: ruta configurada, ok() = true
     * - Si length ≤ 0: error registrado, ok() = false
     * - Estado limpio listo para agregar tiendas/robots
     */
    public void create(int length) {
        if (length <= 0) {
            fail("La longitud de la ruta debe ser mayor a 0");
            return;
        }
        
        this.length = length;
        stores.clear();
        robots.clear();
        profit = 0;
        colorIndex = 0;
        
        if (visible) {
            redraw();
        }
        lastOk = true;
    }
    /**
     * Coloca una nueva tienda en la posición especificada.
     * VALIDACIONES REALIZADAS:
     * - Ruta debe estar creada (length > 0)
     * - Posición debe estar dentro de límites (1 ≤ location ≤ length)
     * - Tenges deben ser no negativos
     * - No puede existir otra tienda en la misma posición
     * 
     * @param location posición en la ruta (1 a length)
     * @param tenges cantidad inicial de dinero (≥ 0)
     * 
     * EFECTOS:
     * - Agrega tienda con color único a la lista
     * - Actualiza visualización si está visible
     * - Actualiza ok() según resultado
     */
    public void placeStore(int location, int tenges) {
    
        if (length == 0) {
            fail("Debe crear una ruta primero usando create()");
            return;
        }
        
        if (location < 1 || location > length) {
            fail("Ubicación inválida para tienda (debe estar entre 1 y " + length + ")");
            return;
        }
        
        if (tenges < 0) {
            fail("Los tenges deben ser un valor positivo o cero");
            return;
        }
        
        for (Store s : stores) {
            if (s.getLocation() == location) {
                fail("Ya existe una tienda en la posición " + location);
                return;
            }
        }
        
        Store nuevaTienda = new Store(stores.size() + 1, location, tenges, nextColor());
        stores.add(nuevaTienda);
        if (visible) {
            redraw();
        }
        lastOk = true;
    }
    
    /**
     * Elimina la tienda ubicada en la posición especificada.
     * 
     * Busca una tienda en la posición indicada y la elimina.
     * Si la tienda tiene representación visual, la oculta primero.
     * @param location posición de la tienda a eliminar
     * 
     * EFECTOS:
     * - Si existe: elimina tienda y actualiza visualización
     * - Si no existe: registra error y actualiza ok()
     */
    public void removeStore(int location) {
        for (int i = 0; i < stores.size(); i++) {
            Store s = stores.get(i);
            if (s.getLocation() == location) {
                // Ocultar figura si está visible
                if (s.getRectangle() != null) {
                    s.getRectangle().makeInvisible();
                }
                // Eliminar de la lista
                stores.remove(i);
                if (visible) {
                    redraw();
                }
                lastOk = true;
                return;
            }
        }
        
        fail("No existe tienda en esa ubicación");
    }

    /**
     * Reabastece todas las tiendas a su cantidad inicial de tenges.
     * Restaura el inventario de todas las tiendas a la cantidad
     * que tenían cuando fueron creadas con placeStore().
     * 
     * EFECTOS:
     * - Todas las tiendas recuperan inventario inicial
     * - Actualiza visualización si es necesaria
     * - ok() = true
     */
    public void resupplyStores() {
        for (Store s : stores) {
            s.resupply();
        }
        if (visible) {
            redraw();
        }
        lastOk = true;
    }

    /**
     * Coloca un nuevo robot en la posición especificada.
     * REQUISITO: Adicionar o eliminar un robot
     * REQUISITO DE DISEÑO:Los robots deben iniciar en localizaciones diferentes
     * 
     * VALIDACIONES REALIZADAS:
     * - Ruta debe estar creada
     * - Posición dentro de límites
     * - No puede existir otro robot con la MISMA posición inicial
     * 
     * @param location posición inicial del robot (1 a length)
     * 
     * EFECTOS:
     * - Agrega robot con color único
     * - Actualiza visualización si visible
     * - Actualiza ok() según resultado
     */
    public void placeRobot(int location) {
        
        if (length == 0) {
            fail("Debe crear una ruta primero usando create()");
            return;
        }
        
        if (location < 1 || location > length) {
            fail("Ubicación inválida para robot (debe estar entre 1 y " + length + ")");
            return;
        }
    
        for (Robot r : robots) {    
            if (r.getInitialLocation() == location) {
                fail("Ya existe un robot con posición inicial en " + location);
                return;
            }
        }

        Robot nuevoRobot = new Robot(robots.size() + 1, location, nextColor());
        robots.add(nuevoRobot);
        if (visible) {
            redraw();
        }
        lastOk = true;
    }   
    
    /**
     * Elimina el robot ubicado en la posición especificada.
     * 
     * Busca un robot en la posición actual indicada y lo elimina.
     * Si el robot tiene representación visual, la oculta primero.
     * 
     * @param location posición actual del robot a eliminar
     * 
     * EFECTOS:
     * - Si existe: elimina robot y actualiza visualización  
     * - Si no existe: registra error
     */
    public void removeRobot(int location) {
        for (int i = 0; i < robots.size(); i++) {
            Robot r = robots.get(i);
            if (r.getLocation() == location) {
                // Ocultar figura si está visible
                if (r.getCircle() != null) {
                    r.getCircle().makeInvisible();
                }
                // Elimina de la lista
                robots.remove(i);
                if (visible) {
                    redraw();
                }
                lastOk = true;
                return;
            }
        }
        fail("No existe robot en esa ubicación");
    }

    /**
     * Devuelve todos los robots a sus posiciones iniciales.
     * 
     * Cada robot regresa a la posición donde fue colocado
     * originalmente con placeRobot().
     * 
     * EFECTOS:
     * - Todos los robots cambian a posición inicial
     * - Actualiza visualización si visible
     * - ok() = true
     */
    public void returnRobots() {
        for (Robot r : robots) {
            r.reset();
        }
        if (visible) {
            redraw();
        }
        lastOk = true;
    }


    /**
     * Mueve un robot desde su ubicación actual.
     * 
     * ALGORITMO:
     * 1. Buscar robot en posición origen 
     * 2. Calcular nueva posición 
     * 3. Validar que esté dentro de límites
     * 4. Validar que no haya otro robot en destino
     * 5. Ejecutar movimiento
     * 6. Verificar si hay tienda en destino y recolectar ganancias
     * 
     * @param location posición actual del robot a mover
     * @param meters cantidad de posiciones a avanzar
     * 
     * EFECTOS:
     * - Robot cambia de posición si es válido
     * - profit puede incrementarse si visita tienda
     * - Tienda visitada puede quedar vacía
     * - Actualiza visualización y ok()
     */
    public void moveRobot(int location, int meters) {
        // Buscar robot en la posición (primero si hay varios)
        Robot robotToMove = null;
        for (Robot r : robots) {
            if (r.getLocation() == location) {
                robotToMove = r;
                break;  // Tomar el primero según requisito de diseño
            }
        }
    
        // Validar que existe robot
        if (robotToMove == null) {
            fail("No existe robot en esa ubicación");
            return;
        }
    
        // Calcular nueva posición
        int newLocation = robotToMove.getLocation() + meters;
        if (newLocation < 1 || newLocation > length) {
            fail("Movimiento fuera de la ruta (posición resultante: " + newLocation + ")");
            return;
        }
    
        // Validar que no haya colisión con otro robot
        for (Robot other : robots) {
            if (other != robotToMove && other.getLocation() == newLocation) {
                fail("Ya hay un robot en la posición " + newLocation);
                return;
            }
        }
    
        // Ejecutar movimiento
        robotToMove.moveToLocation(newLocation);
    
        // Verificar si hay tienda en destino y recolectar ganancias
        for (Store s : stores) {
            if (s.getLocation() == newLocation && !s.isEmpty()) {
                int collected = s.withdraw(s.getTenges());
                profit += collected;
                break; // Solo puede haber una tienda por posición
            }
        }
    
        if (visible) {
            redraw();
        }
        lastOk = true;
    }
    
    /**
     * Reinicia la ruta de seda manteniendo configuración de tiendas y robots.
     * 
     * OPERACIONES:
     * - Resetea ganancias a 0
     * - Reabastece todas las tiendas
     * - Devuelve robots a posiciones iniciales
     * - Mantiene la configuración (ubicaciones, colores, etc.)
     * 
     * EFECTOS:
     * - profit = 0
     * - Tiendas con inventario completo
     * - Robots en posiciones iniciales
     * - Actualiza visualización y ok()
     */
    public void reboot() {
        profit = 0;
        resupplyStores();
        returnRobots();
        if (visible) {
            redraw();
        }
        lastOk = true;
    }
    
    /**
     * Consulta las ganancias totales acumuladas.
     * 
     * Las ganancias se acumulan cuando los robots pasan por tiendas
     * con inventario disponible.
     * 
     * @return cantidad total de ganancias acumuladas
     */
    public int profit() {
        return profit;
    }

    /**
     * Consulta las posiciones de todas las tiendas.
     * 
     * @return array con ubicaciones de tiendas en orden de creación
     */
    public int[] stores() {
        int[] arr = new int[stores.size()];
        for (int i = 0; i < stores.size(); i++) {
            arr[i] = stores.get(i).getLocation();
        }
        return arr;
    }

    /**
     * Consulta las posiciones actuales de todos los robots.
     * 
     * Las posiciones pueden diferir de las iniciales si se han movido.
     * 
     * @return array con ubicaciones actuales de robots en orden de creación
     */
    public int[] robots() {
        int[] array = new int[robots.size()];
        for (int i = 0; i < robots.size(); i++) {
            array[i] = robots.get(i).getLocation();
        }
        return array;
    }
    
    /**
     * Hace visible el simulador.
     * 
     * En modo visible:
     * - Se muestran todos los elementos gráficos
     * - Las operaciones actualizan la visualización
     * - Los errores se reportan en consola
     * 
     * EFECTOS:
     * - visible = true
     * - Redibuja toda la interfaz
     */
    public void makeVisible() {
        this.visible = true;
        redraw();
    }

    /**
     * Hace invisible el simulador.
     * 
     * En modo invisible:
     * - Todos los elementos gráficos se ocultan
     * - El simulador funciona sin interfaz visual
     * - Los errores se suprimen
     * 
     * EFECTOS:
     * - visible = false
     * - Oculta todos los elementos gráficos
     */
    public void makeInvisible() {
        this.visible = false;
        // Ocultar todos los elementos
        for (Store s : stores) {
            if (s.getRectangle() != null) {
                s.getRectangle().makeInvisible();
            }
        }
        for (Robot r : robots) {
            if (r.getCircle() != null) {
                r.getCircle().makeInvisible();
            }
        }
        if (profitBar != null) {
            profitBar.makeInvisible();
        }
        if (profitBackground != null) {
            profitBackground.makeInvisible();
        }
    }
    
    /**
     * Termina el simulador y limpia todos los recursos.
     * 
     * OPERACIONES:
     * - Elimina todas las tiendas y robots
     * - Resetea ganancias a 0
     * - Oculta elementos gráficos si están visibles
     * 
     * EFECTOS:
     * - Estado limpio y vacío
     * - Listo para nueva configuración
     */
    public void finish() {
        // Ocultar elementos antes de limpiar
        if (visible) {
            makeInvisible();
        }
        
        stores.clear();
        robots.clear();
        profit = 0;
        length = 0;  
        colorIndex = 0;
        lastOk = true;
    }

    /**
     * Indica si la última operación fue exitosa.
     * 
     * ESPECIFICACIÓN: ok() boolean según requisitos de diseño
     * 
     * @return true si la última operación se ejecutó correctamente,
     *         false si falló por validaciones o errores
     */
    public boolean ok() {
        return lastOk;
    }

    
    /**
     * Redibuja completamente la interfaz gráfica.
     * 
     * PROCESO:
     * 1. Oculta todos los elementos existentes
     * 2. Dibuja tiendas como rectángulos en posiciones de espiral
     * 3. Dibuja robots como círculos en posiciones de espiral
     * 4. Actualiza barra de progreso de ganancias
     * 
     * Solo se ejecuta si visible = true.
     */
    private void redraw() {
        if (!visible) return;
        
        // Paso 1: Ocultar elementos existentes
        for (Store s : stores) {
            if (s.getRectangle() != null) {
                s.getRectangle().makeInvisible();
            }
        }
        for (Robot r : robots) {
            if (r.getCircle() != null) {
                r.getCircle().makeInvisible();
            }
        }
        if (profitBar != null) {
            profitBar.makeInvisible();
        }
        if (profitBackground != null) {
            profitBackground.makeInvisible();
        }

        // Paso 2: Dibujar tiendas
        for (Store s : stores) {
            // Calcular posición en espiral
            int[] pos = Spiral.getCoords(s.getLocation());
            int x = CENTER_X + pos[0] * CELL_SIZE;
            int y = CENTER_Y - pos[1] * CELL_SIZE;

            // Crear rectángulo para la tienda
            Rectangle rect = new Rectangle();
            rect.changeSize(CELL_SIZE - 5, CELL_SIZE - 5);
            rect.changeColor(s.getColorName());
            rect.moveTo(x, y);
            rect.makeVisible();
            s.setRectangle(rect);
        }

        // Paso 3: Dibujar robots
        for (Robot r : robots) {
            // Calcular posición en espiral
            int[] pos = Spiral.getCoords(r.getLocation());
            int x = CENTER_X + pos[0] * CELL_SIZE;
            int y = CENTER_Y - pos[1] * CELL_SIZE;

            // Crear círculo para el robot
            Circle c = new Circle();
            c.changeSize(CELL_SIZE - 10);
            c.changeColor(r.getColorName());
            c.moveTo(x, y);
            c.makeVisible();
            r.setCircle(c);
        }
        // Paso 4: Dibujar barra de progreso
        drawProfitBar();
    }

    /**
     * Dibuja la barra de progreso de ganancias.
     * 
     * de una barra de progreso donde el máximo es la ganancia máxima posible 
     * en el momento. No deben adicionar números."
     * 
     * COMPONENTES:
     * - Fondo negro: representa el máximo posible
     * - Relleno verde: representa las ganancias actuales
     * - Sin números: solo representación visual
     */
    private void drawProfitBar() {
        // Calcular ganancia máxima posible
        int max = profit;  // Ganancias actuales
        for (Store s : stores) {
            max += s.getTenges();  // + inventarios restantes
        }
        if (max == 0) max = 1;  // Evitar división por cero
        // Dimensiones de la barra
        int width = 200;
        int height = 20;
        int filled = (profit * width) / max;  // Porción llenada
        // Fondo de la barra (negro - representa máximo)
        profitBackground = new Rectangle();
        profitBackground.changeSize(height, width);
        profitBackground.changeColor("black");
        profitBackground.moveTo(50, 280);
        profitBackground.makeVisible();
        // Relleno de la barra (verde - representa progreso)
        profitBar = new Rectangle();
        profitBar.changeSize(height, filled);
        profitBar.changeColor("green");
        profitBar.moveTo(50, 280);
        profitBar.makeVisible();
    }

    /**
     * Registra una operación como fallida y reporta error si es visible
     * un mensaje especial al usuario, sólo si el simulador está visible.
     * 
     * @param msg mensaje descriptivo del error
     * 
     * EFECTOS:
     * - lastOk = false
     * - Si visible: muestra error en consola
     * - Si invisible: error silencioso
     */
    private void fail(String msg) {
        lastOk = false;
        if (visible) {
            System.out.println("ERROR: " + msg);
        }
    }

    /**
     * Obtiene el siguiente color disponible de la paleta.
     * 
     * Los colores se asignan cíclicamente. Si se agotan los colores únicos,
     * el patrón se repite para garantizar disponibilidad.
     * 
     * @return color como String válido para shapes
     * 
     * EFECTOS:
     * - Incrementa colorIndex para siguiente uso
     * - Reseteo cíclico al final de la paleta
     */
    private String nextColor() {
        String c = colors[colorIndex];
        colorIndex = (colorIndex + 1) % colors.length;
        return c;
    }
}