import shapes.Rectangle;

/**
 * Representa una tienda dentro del simulador de la Ruta de la Seda.
 *
 * Cada tienda:
 * Tiene un identificador único.
 * Tiene una ubicación en la ruta.
 * Almacena una cierta cantidad de tenges.
 * Tiene un color único.
 * Puede representarse visualmente con un Rectangle en el Canvas.
 *
 * Requisitos relacionados:
 * Adicionar o eliminar una tienda
 * Reabastecer todas las tiendas
 * Reiniciar la ruta con las tiendas en estado inicial
 * 
 * @author Camilo Aguirre- Mateo Sanchez
 * @version 28-09-2025
 */
public class Store {
    private int id;
    private int location;     
    private int tenges;
    private int initialTenges;
    private String colorName;

    private Rectangle rectangle; 

    /**
     * Crea una tienda en la ubicación dada, con la cantidad inicial de tenges.
     *
     * @param id         identificador único de la tienda
     * @param location   posición en la ruta
     * @param tenges     cantidad inicial de tenges
     * @param colorName  color de la tienda ("red", "blue", etc.)
     */
    public Store(int id, int location, int tenges, String colorName) {
        this.id = id;
        this.location = location;
        this.tenges = tenges;
        initialTenges = tenges;
        this.colorName = colorName;
        rectangle = null; 
    }
    /** Devuelve el identificador único del objeto.*/
    public int getId() {
        return id; 
    }

    /** Devuelve la ubicación actual del objeto dentro de la ruta o tablero. */
    public int getLocation() { 
        return location; 
    }

    /** Devuelve la cantidad actual de tenges que posee el objeto.*/
    public int getTenges() { 
        return tenges; 
    }

    /**Devuelve el nombre del color asignado al objeto.*/
    public String getColorName() { 
        return colorName; 
    }
    /** Reabastece la tienda con la cantidad inicial de tenges. */
    public void resupply() {
        tenges = initialTenges;
    }

    /** @return true si la tienda ya no tiene tenges. */
    public boolean isEmpty() {
        return tenges <= 0;
    }

    /**
     * Retira hasta 'amount' tenges de la tienda.
     * @param amount cantidad a retirar
     * @return cantidad realmente retirada
     */
    public int withdraw(int amount) {
        int taken = Math.max(0, Math.min(amount, tenges));
        tenges = tenges - taken;
        return taken;
    }

    /** Asigna el rectángulo que representa visualmente a la tienda. */
    public void setRectangle(Rectangle r) {
        this.rectangle = r;
    }

    /** Devuelve la figura Rectangle asociada (puede ser null si no está visible). */
    public Rectangle getRectangle() {
        return rectangle;
    }

    /**
     * Configura tamaño, posición y visibilidad de la figura ya asociada.
     *
     * @param x         coordenada X (px) donde se dibujará
     * @param y         coordenada Y (px)
     * @param widthPx   ancho en píxeles (BlueJ usa changeSize(alto, ancho))
     * @param heightPx  alto en píxeles
     * @param visible   si true, la figura se hace visible
     */
    public void mountAt(int x, int y, int widthPx, int heightPx, boolean visible) {
        if (rectangle == null) 
            return;
            rectangle.changeColor(colorName);
            rectangle.changeSize(heightPx, widthPx);
            rectangle.moveTo(x, y);
            if (visible) 
                rectangle.makeVisible();
            else {rectangle.makeInvisible();
            }
    }

    /** Muestra u oculta la figura asociada. */
    public void setVisible(boolean v) {
        if (rectangle == null) 
            return;
            if (v) 
                rectangle.makeVisible();
            else{
            rectangle.makeInvisible();
            }
    }

    /** Cambia el color de la tienda (y de la figura si existe). */
    public void setColor(String newColor) {
        this.colorName = newColor;
        if (rectangle != null) 
        rectangle.changeColor(newColor);
    }

    /**
     * Libera la vista: oculta y “desasocia” el Rectangle.
     * Útil cuando se elimina la tienda del simulador.
     */
    public void disposeView() {
        if (rectangle != null) {
            rectangle.makeInvisible();
            rectangle = null;
        }
    }
}
