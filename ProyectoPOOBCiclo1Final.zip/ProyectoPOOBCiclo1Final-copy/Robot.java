import shapes.*;
/**
 * Representa un robot dentro del simulador de la Ruta de la Seda.
 *
 * Cada robot:
 * Tiene un identificador único (id).
 * Tiene una posición inicial y una posición actual en la ruta.
 * Tiene un color.
 * Se representa visualmente con un Circle en el Canvas.
 *
 * Requisitos relacionados:
 * Adicionar o eliminar robots
 * Retornar robots a su posición inicial
 * Mover un robot
 *
 * @author
 *Camilo Aguirre - Mateo Sanchez
 * @version 28-09-2025
 */
public class Robot {
    private int id;
    private int initialLocation; 
    private int currentLocation;  
    private String colorName;
    private Circle circle;   

    /**
     * Crea un nuevo robot en la posición indicada.
     *
     * @param id         Identificador único del robot
     * @param location   Posición inicial del robot en la ruta
     * @param colorName  Color del robot ("red", "blue", "green", etc.)
     */
    public Robot(int id, int location, String colorName) {
        this.id = id;
        initialLocation = location;
        currentLocation = location;
        this.colorName = colorName;
        circle = null; // la figura se añade después (composición)
    }

    /**Obtiene el identificador único del robot. */
    public int getId() {
        return id; 
    }

    /** Consulta la ubicación actual del robot en la ruta.*/
    public int getLocation() { 
        return currentLocation; 
    }

    /**Consulta la ubicación inicial del robot. */
    public int getInitialLocation() { 
        return initialLocation;     
    }

    /** Obtiene el nombre del color asignado al robot.*/
    public String getColorName() { 
        return colorName; 
    }

    /** Mueve el robot a una nueva ubicación dentro de la ruta. */
    public void moveToLocation(int newLocation) {
        currentLocation = newLocation;
    }

    /** Retorna el robot a su posición inicial. */
    public void reset() {
        currentLocation = this.initialLocation;
    }

    /** Asigna el círculo que representa gráficamente al robot. */
    public void setCircle(Circle c) {
        this.circle = c;
    }

    /** Obtiene la figura (Circle) del robot; puede ser null si no está visible. */
    public Circle getCircle() {
        return circle;
    }

    /**
     * Configura tamaño, posición y visibilidad de la figura ya asociada.
     * @param x         coordenada X 
     * @param y         coordenada Y 
     * @param diameter  diámetro del círculo en píxeles
     * @param visible   si es true, hace visible la figura
     */
    public void drawAt(int x, int y, int diameter, boolean visible) {
        if (circle == null) {
            return;
        }

        circle.changeColor(colorName);
        circle.changeSize(diameter);
        circle.moveTo(x, y);

        if (visible) {
            circle.makeVisible();
        } else {
            circle.makeInvisible();
        }
    }

    /** 
     * Muestra u oculta la figura asociada. 
     */
    public void setVisible(boolean v) {
        if (circle == null) {
            return;
        }
    
        if (v) {
            circle.makeVisible();
        } else {
            circle.makeInvisible();
        }
    }

    /** Cambia el color del robot (y de la figura si existe). */
    public void setColor(String newColor) {
        this.colorName = newColor;
        if (circle != null) {
            circle.changeColor(newColor);
        }
    }

    /**
     * Libera la vista: oculta o desasocia el Circle
    */
    public void disposeView() {
        if (circle != null) {
            circle.makeInvisible();
            circle = null;
        }
    }
}
