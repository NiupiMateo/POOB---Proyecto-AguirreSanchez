package SilkroadFinal;
import java.util.*;
/**
 * Modelo de la Ruta de la Seda.
 * Administra la lista de robots y tiendas, calcula ganancias,
 * y permite reiniciar y actualizar el estado de la simulación.
 * 
 * Aplica el patrón MVC: este componente es la parte "Model".
 * 
 * @Camilo Aguirre-Mateo Sanchez
 * @version 7/09/2025
 */
public class SilkRoadModel {
    private int length;
    private Map<Integer, Robot> robots;
    private Map<Integer, Store> stores;
    private int profit;
     /**
     * Construye un modelo de ruta con una longitud dada.
     * @param length longitud de la ruta
     */
    public SilkRoadModel(int length) {
        this.length = length;
        this.robots = new HashMap<>();
        this.stores = new HashMap<>();
        this.profit = 0;
    }
    /** Agrega un robot al modelo */
    public void addRobot(Robot r) {
        robots.put(r.getId(), r);
    }
    /** Elimina un robot por id */
    public void removeRobot(int id) {
        robots.remove(id);
    }
    /** Agrega una tienda al modelo */
    public void addStore(Store s) {
        stores.put(s.getId(), s);
    }
    /** Elimina una tienda por id */
    public void removeStore(int id) {
        stores.remove(id);
    }
    /** Resetea las tiendas a su estado inicial */
    public void resupplyStores() {
        for (Store s : stores.values()) {
            s.resupply();
        }
    }
    /** Reinicia la ruta completa: robots y tiendas */
    public void resetRoute() {
        for (Robot r : robots.values()) {
            r.reset();
        }
        resupplyStores();
        profit = 0;
    }
     /**
     * Mueve un robot hacia una tienda, calculando la ganancia
     * y actualizando posiciones.
     * @param robotId id del robot a mover
     * @param storeId id de la tienda destino
     */
    public void moveRobotToStore(int robotId, int storeId) {
        Robot r = robots.get(robotId);
        Store s = stores.get(storeId);
        if (r != null && s != null && !s.isEmpty()) {
            int distance = Math.abs(r.getCurrentPos() - s.getPos());
            int gain = s.getCurrentAmount() - distance;
            if (gain > 0) {
                profit += gain;
            }
            r.setCurrentPos(s.getPos());
            s.empty();
        }
    }
    /**retorna ganancia acumulada */
    public int getProfit() {
        return profit;
    }
    /**retorna información general de la ruta */
    public String getRouteInfo() {
        return "Robots: " + robots.size() +
               ", Stores: " + stores.size() +
               ", Profit: " + profit;
    }
    /**retorna mapa de robots */
    public Map<Integer, Robot> getRobots() {
        return robots;
    }
    /**retorna mapa de tiendas */
     public Map<Integer, Store> getStores() {
        return stores;
    }
}
