package SilkroadFinal;
import shapes.*;
import java.util.*;
/**
 * Vista de la Ruta de la Seda.
 * Encargada de mostrar gráficamente los robots y tiendas
 * usando figuras del paquete shapes.
 * 
 * Aplica el patrón MVC: este componente es la parte "View".
 * 
 * @Camilo Aguirre-Mateo Sanchez
 * @version 07/09/2025
 */
public class SilkRoadView {
    private SilkRoadModel model;
    private boolean visible;
    private Canvas canvas;
    private List<Object> drawnShapes;
     /**
     * Construye una vista asociada a un modelo.
     * @param model modelo de la ruta
     */
    public SilkRoadView(SilkRoadModel model) {
        this.model = model;
        this.visible = false;
        this.canvas = Canvas.getCanvas();
        this.drawnShapes = new ArrayList<>();
    }
    /** Hace visible la vista */
    public void show() {
        this.visible = true;
        render();
    }
    /** Oculta la vista */
    public void hide() {
        this.visible = false;
        clearCanvas();
    }
    /** Cierra la vista y borra el canvas */
    public void close() {
        this.visible = false;
        clearCanvas();
    }
    /** Redibuja la ruta con robots y tiendas */
    public void render() {
        if (!visible) return;

        clearCanvas();
        for (Store s : model.getStores().values()) {
            drawStore(s);
        }

        for (Robot r : model.getRobots().values()) {
            drawRobot(r);
        }
    }
    /** Dibuja un robot en el canvas */
    private void drawRobot(Robot r) {
        Circle robotShape = new Circle();
        robotShape.changeColor(r.getColor()); 
        robotShape.moveHorizontal(r.getCurrentPos() * 20);
        robotShape.moveVertical(100); 
        robotShape.makeVisible();
        drawnShapes.add(robotShape);
    }
    /** Dibuja una tienda en el canvas */
    private void drawStore(Store s) {
        Rectangle storeShape = new Rectangle();
        storeShape.changeColor(s.getColor());
        storeShape.moveHorizontal(s.getPos() * 20);
        storeShape.moveVertical(200); 
        storeShape.makeVisible();
        drawnShapes.add(storeShape);
    }
    /** Borra las figuras dibujadas previamente */
    private void clearCanvas() {
        for (Object shape : drawnShapes) {
            canvas.erase(shape);
        }
        drawnShapes.clear();
    }
}

