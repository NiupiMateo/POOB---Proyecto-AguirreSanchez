package SilkroadFinal;
/**
 * Clase principal del simulador de la Ruta de la Seda.
 * Controla el modelo y la vista, actuando como controlador
 * dentro del patrón MVC.
 * 
 * Permite añadir/eliminar robots y tiendas, mover robots,
 * reiniciar la ruta, y visualizar gráficamente la simulación.
 * 
 * @Camilo Aguirre-Mateo Sanchez
 * @version 7/09/2025
 */
public class SilkRoadSimulator {
    private SilkRoadModel model;
    private SilkRoadView view;
    private boolean visible;
     /**
     * Construye el simulador con una ruta de cierta longitud.
     * @param length longitud de la ruta
     */
    public SilkRoadSimulator(int length) {
        this.model = new SilkRoadModel(length);
        this.view = new SilkRoadView(model);
        this.visible = false;
    }
    /** Alterna entre mostrar y ocultar la vista */
    public void toggleVisibility() {
        if (visible) {
            view.hide();
            visible = false;
        } else {
            view.show();
            visible = true;
        }
    }
    /** Termina el simulador */
    public void terminate() {
        view.close();
        visible = false;
    }
    /** Agrega un robot al simulador */
    public void addRobot(int id, int pos,String color) {
        Robot r = new Robot(id, pos, color);
        model.addRobot(r);
        view.render(); 
    }
    /** Elimina un robot por id */
    public void removeRobot(int id) {
        model.removeRobot(id);
        view.render(); 
    }
    /** Agrega una tienda al simulador */
    public void addStore(int id, int pos, int amount, String color) {
        Store s = new Store(id, pos, amount, color);
        model.addStore(s);
        view.render();
    }
    /** Elimina una tienda por id */
    public void removeStore(int id) {
        model.removeStore(id);
        view.render(); 
    }
    /** Mueve un robot a una tienda */
    public void moveRobot(int robotId, int storeId) {
        model.moveRobotToStore(robotId, storeId);
        view.render(); 
    }
    /** Reabastece todas las tiendas */
    public void resupplyStores() {
        model.resupplyStores();
        view.render(); 
    }
    /** Reinicia la ruta a su estado inicial */
    public void resetRoute() {
        model.resetRoute();
        view.render(); 
    }
    /**retorna ganancia acumulada */
    public int getProfit() {
        return model.getProfit();
    }
    /**retorna información de la ruta */
    public String getRouteInfo() {
        return model.getRouteInfo();
    }
}
