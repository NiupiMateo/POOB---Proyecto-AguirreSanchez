package SilkroadFinal;
/**
 * Representa una tienda dentro de la Ruta de la Seda.
 * Cada tienda tiene un identificador, posición, cantidad de mercancía inicial
 * y actual, además de un color que la distingue gráficamente.
 * 
 * @Camilo Aguirre-Mateo Sanchez
 * @version 7/09/2025
 */
public class Store {
    private int id;
    private int pos;
    private int amount;
    private int initialAmount;
    private String color; 
    /**
     * Construye una tienda con identificador, posición, cantidad de mercancía
     * y color.
     * @param id identificador único de la tienda
     * @param pos posición de la tienda en la ruta
     * @param amount cantidad inicial de mercancía
     * @param color color de la tienda
     */
    public Store(int id, int pos, int amount, String color) {
        this.id = id;
        this.pos = pos;
        this.amount = amount;
        this.initialAmount = amount;
        this.color = color;
    }
    /** retorna identificador de la tienda */
    public int getId() {
        return id;
    }
    /** retorna posición de la tienda */
    public int getPos() {
        return pos;
    }
    /** retorna cantidad actual de mercancía */
    public int getCurrentAmount() {
        return amount;
    }
    /** retorna true si la tienda no tiene mercancía */
    public boolean isEmpty() {
        return amount <= 0;
    }
    /** Vacía la tienda (mercancía = 0) */
    public void empty() {
        this.amount = 0;
    }
    /** Restaura la cantidad de mercancía inicial */
    public void resupply() {
        this.amount = initialAmount;
    }
    /** retorna color de la tienda */
    public String getColor() { 
        return color;
    }
}
