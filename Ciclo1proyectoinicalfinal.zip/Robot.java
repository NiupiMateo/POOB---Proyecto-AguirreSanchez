package SilkroadFinal;
/**
 * Representa un robot dentro de la Ruta de la Seda.
 * Cada robot tiene un identificador, posición actual, posición inicial
 * y un color que lo distingue gráficamente.
 * 
 * @Camilo Aguirre-Mateo Sanchez
 * @version 7/09/2025
 */

public class Robot {
    private int id;
    private int currentPos;
    private int initialPos;
    private String color;
     /**
     * Construye un robot con un identificador, posición inicial y color.
     * @param id identificador único del robot
     * @param pos posición inicial en la ruta
     * @param color color del robot
     */

    public Robot(int id, int pos, String color) {
        this.id = id;
        this.currentPos = pos;
        this.initialPos = pos;
        this.color = color;
    }
    /** retorna identificador único del robot */
    public int getId() {
        return id;
    }
    /** retorna posición actual del robot */
    public int getCurrentPos() {
        return currentPos;
    }
    /** @param pos nueva posición del robot en la ruta */
    public void setCurrentPos(int pos) {
        this.currentPos = pos;
    }
    /** Reinicia el robot a su posición inicial */
    public void reset() {
        this.currentPos = initialPos;
    }
    /** retorna color del robot */
    public String getColor() { 
        return color;
    }
}
