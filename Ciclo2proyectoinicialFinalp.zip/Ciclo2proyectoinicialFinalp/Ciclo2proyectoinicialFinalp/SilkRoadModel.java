import java.util.*;
/**
 * Modelo de la Ruta de la Seda.
 * Administra la lista de robots y tiendas, calcula ganancias,
 * y permite reiniciar y actualizar el estado de la simulación.
 * 
 * Aplica el patrón MVC: este componente es la parte "Model".
 * 
 * @Camilo Aguirre-Mateo Sanchez
 * @version 7/09/2025
 */
public class SilkRoadModel {
    private int length;
    private Map<Integer, Robot> robots;
    private Map<Integer, Store> stores;
    private int profit;
     /**
     * Construye un modelo de ruta con una longitud dada.
     * @param length longitud de la ruta
     */
    public SilkRoadModel(int length) {
        this.length = length;
        robots = new HashMap<>();
        stores = new HashMap<>();
        profit = 0;
    }
    /** Agrega un robot al modelo */
    public void addRobot(Robot r) {
        robots.put(r.getId(), r);
    }
    /** Elimina un robot por id */
    public void removeRobot(int id) {
        robots.remove(id);
    }
    /** Agrega una tienda al modelo */
    public void addStore(Store s) {
        stores.put(s.getId(), s);
    }
    /** Elimina una tienda por id */
    public void removeStore(int id) {
        stores.remove(id);
    }
    /** Resetea las tiendas a su estado inicial */
    public void resupplyStores() {
        for (Store s : stores.values()) {
            s.resupply();
        }
    }
    /** Reinicia la ruta completa: robots y tiendas */
    public void resetRoute() {
        for (Robot r : robots.values()) {
            r.reset();
        }
        resupplyStores();
        profit = 0;
    }
     /**
     * Mueve un robot hacia una tienda, calculando la ganancia
     * y actualizando posiciones.
     * Reglas:
     * La ganancia se calcula como (mercancía de la tienda - distancia).
     * Si la ganancia es positiva, se suma tanto a la ganancia global (del simulador)
     * como a la ganancia individual del robot.
     * El robot cambia su posición a la de la tienda.
     * La tienda se vacía (amount = 0) y se registra que fue desocupada una vez más.
     * @param robotId id del robot a mover
     * @param storeId id de la tienda destino
     */
    public void moveRobotToStore(int robotId, int storeId) {
        Robot r = robots.get(robotId);
        Store s = stores.get(storeId);
        if (r != null && s != null && !s.isEmpty()) {
            int distance = Math.abs(r.getCurrentPos() - s.getPos());
            int gain = s.getCurrentAmount() - distance;
            if (gain > 0) {
                profit += gain;     // ganancia global
                r.addProfit(gain);  // ganancia individual del robot
            }
            r.setCurrentPos(s.getPos());
            s.empty();
            s.markEmptied();        // también registramos si la tienda quedó vacía
        }
    }

    /**retorna ganancia acumulada */
    public int getProfit() {
        return profit;
    }
    /**retorna información general de la ruta */
    public String getRouteInfo() {
        return "Robots: " + robots.size() +
               ", Stores: " + stores.size() +
               ", Profit: " + profit;
    }
    /**retorna mapa de robots */
    public Map<Integer, Robot> getRobots() {
        return robots;
    }
    /**retorna mapa de tiendas */
     public Map<Integer, Store> getStores() {
        return stores;
    }
        /**
     * Determina cuál es la tienda más rentable para un robot.
     * @param robotId identificador del robot
     * @return id de la tienda más rentable, o -1 si no hay tiendas disponibles
     */
    public int bestStoreForRobot(int robotId) {
        Robot r = robots.get(robotId);
        if (r == null) return -1;

        int bestStoreId = -1;
        int bestGain = Integer.MIN_VALUE;

        for (Store s : stores.values()) {
            if (!s.isEmpty()) {
                int distance = Math.abs(r.getCurrentPos() - s.getPos());
                int gain = s.getCurrentAmount() - distance;
                if (gain > bestGain) {
                    bestGain = gain;
                    bestStoreId = s.getId();
                }
            }
        }
        return bestStoreId;
    }
    public void clearStores() {
        stores.clear();
    }
    /** Consulta cuántas veces una tienda ha sido desocupada */
    public int getTimesStoreEmptied(int storeId) {
        Store s = stores.get(storeId);
        return (s != null) ? s.getTimesEmptied() : 0;
    }
    /** Retorna la ganancia acumulada de un robot */
    public int getRobotProfit(int robotId) {
        Robot r = robots.get(robotId);
        return (r != null) ? r.getProfit() : 0;
    }
}
