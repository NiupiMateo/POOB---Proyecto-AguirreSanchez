import java.util.*;
import static org.junit.Assert.*;
import org.junit.Test;
/**
 * Casos de prueba colectivos (Ciclo 2).
 * Incluyen iniciales AS (Aguirre–Sánchez).
 * 
 * @author AS
 * @version 21/09/2025
 */
public class SilkRoadCC2Test {
    
    @Test
    public void accordingASShouldNotMoveIfRobotDoesNotExist() {
        SilkRoadSimulator sim = new SilkRoadSimulator(30);
        sim.addStore(1, 5, 10, "red");
        int initialProfit = sim.getProfit();
        sim.moveRobotToBestStore(99);
        assertEquals("No debe haber cambio en ganancia porque no hay robot", initialProfit, sim.getProfit());
    }
    
    @Test
    public void accordingASShouldHandleMultipleLinesInMarathonInput() {
        SilkRoadSimulator sim = new SilkRoadSimulator(50);
        List<String> input = new ArrayList<>();
        input.add("1 5 10");
        input.add("2 8 15 12 20");
        
        try {
            sim.createFromMarathonInput(input);
            sim.addRobot(1, 0, "yellow");
            sim.moveRobotToBestStore(1);
            assertTrue("Las tiendas deben haberse creado correctamente", true);
            String simInfo = sim.toString();
            assertTrue("Debe contener información de las tiendas creadas", 
                      simInfo != null && simInfo.length() > 0);
        } catch (Exception e) {
            fail("El método createFromMarathonInput falló: " + e.getMessage());
        }
    }
    
    @Test
    public void accordingASShouldChooseFirstStoreWhenProfitIsEqual() {
        SilkRoadSimulator sim = new SilkRoadSimulator(50);
        sim.addStore(1, 5, 10, "red");
        sim.addStore(2, 15, 20, "blue");
        sim.addRobot(1, 0, "yellow");
        sim.moveRobotToBestStore(1);
        int finalProfit = sim.getProfit();
        assertEquals("El profit debe ser 5 (primera tienda seleccionada)", 5, finalProfit);
        String simState = sim.toString();
        if (simState != null) {
            assertTrue("El estado debe mostrar que hubo movimiento", !simState.isEmpty());
        }
    }
}