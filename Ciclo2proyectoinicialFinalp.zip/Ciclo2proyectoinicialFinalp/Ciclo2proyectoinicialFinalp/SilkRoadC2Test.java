import java.util.*;
import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Pruebas de unidad para el ciclo 2 del proyecto Silk Road.
 * 
 * Verifica las nuevas funcionalidades:
 * -moveRobotToBestStore
 * -createFromMarathonInput
 * 
 * @author Camilo Aguirre- Mateo Sanchez
 * @version 21/09/2025
 */
public class SilkRoadC2Test {
    
    @Test
    public void testMoveRobotToBestStore() {
        SilkRoadSimulator sim = new SilkRoadSimulator(50);
        sim.addStore(1, 5, 20, "red");
        sim.addStore(2, 10, 30, "blue");
        sim.addRobot(1, 0, "yellow");
        
        sim.moveRobotToBestStore(1);
        
        // La tienda 2 es la más rentable debido a que: ganancia = 30 - 10 = 20
        assertEquals("Ganancia incorrecta", 20, sim.getProfit());
    }
    
    @Test
    public void testMoveRobotToBestStoreWithoutStores() {
        SilkRoadSimulator sim = new SilkRoadSimulator(50);
        sim.addRobot(1, 0, "yellow");
        
        sim.moveRobotToBestStore(1);
        
        // No hay tiendas, no debería ganar nada
        assertEquals("Ganancia debe ser 0 sin tiendas", 0, sim.getProfit());
    }
    
    @Test
    public void testCreateFromMarathonInput() {
        SilkRoadSimulator sim = new SilkRoadSimulator(50);
        List<String> input = new ArrayList<>();
        input.add("2 5 10 8 20"); // dos tiendas: (5,10) y (8,20)
        
        sim.createFromMarathonInput(input);
        
        // Ganancia aún debe ser 0 (ningún robot se ha movido aun)
        assertEquals("La ganancia debe empezar en 0", 0, sim.getProfit());
        
        // Confirmamos que las tiendas se registraron getRouteInfo no debe estar vacío
        assertTrue("No se registraron las tiendas", sim.getRouteInfo().length() > 0);
    }
    
    @Test
    public void testCreateFromEmptyInput() {
        SilkRoadSimulator sim = new SilkRoadSimulator(50);
        List<String> input = new ArrayList<>();
        
        sim.createFromMarathonInput(input);
        
        // No se crean tiendas ni robots, la ganancia debe seguir en 0
        assertEquals("Ganancia debe ser 0 con entrada vacía", 0, sim.getProfit());
    }
}
