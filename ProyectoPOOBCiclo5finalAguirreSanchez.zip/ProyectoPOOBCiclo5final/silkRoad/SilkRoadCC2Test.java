package silkRoad;

import org.junit.Test;
import static org.junit.Assert.*;

public class SilkRoadCC2Test {

    private int[][] sampleDays() {
        return new int[][] {
            {1, 20},
            {2, 15, 15},
            {2, 40, 50},
            {1, 50},
            {2, 80, 20},
            {2, 70, 30}
        };
    }

    @Test
    public void accordingASShouldResetProfitToZeroAfterReboot() {
        SilkRoad s = new SilkRoad(sampleDays());
        s.makeInvisible();
        s.moveRobots();
        assertTrue(s.profit() > 0);
        s.reboot();
        assertEquals(0, s.profit());
    }

    @Test
    public void accordingASShouldResupplyStoresToInitialAfterReboot() {
        SilkRoad s = new SilkRoad(sampleDays());
        s.makeInvisible();
        s.moveRobots();
        int[][] locs = s.stores();
        s.reboot();
        int before = s.profit();
        s.moveRobots();
        int after = s.profit();
        assertTrue(after > before);
    }

    @Test
    public void accordingASShouldReturnRobotsToInitialLocationsAfterReboot() {
        SilkRoad s = new SilkRoad(10);
        s.makeInvisible();
        s.placeRobot(3);
        s.placeRobot(8);
        s.placeStore(5, 10);
        s.moveRobot(3, 2);
        
        // Después del movimiento: robot en pos 5 (movió de 3 a 5) y robot en pos 8
        int[][] robotsAfterMove = s.robots();
        assertEquals(2, robotsAfterMove.length);
        assertEquals(5, robotsAfterMove[0][0]); // primer robot movió a 5
        assertEquals(8, robotsAfterMove[1][0]); // segundo robot sigue en 8
        
        s.reboot();
        
        // Después del reboot: robots vuelven a posiciones iniciales 3 y 8
        int[][] robotsAfterReboot = s.robots();
        assertEquals(2, robotsAfterReboot.length);
        assertEquals(3, robotsAfterReboot[0][0]); // primer robot vuelve a 3
        assertEquals(8, robotsAfterReboot[1][0]); // segundo robot sigue en 8
    }

    @Test
    public void accordingASShouldKeepConfigurationAndSetOkTrueAfterReboot() {
        SilkRoad s = new SilkRoad(sampleDays());
        s.makeInvisible();
        int initialStoresCount = s.stores().length;
        int initialRobotsCount = s.robots().length;
        s.moveRobots();
        s.reboot();
        assertEquals(initialStoresCount, s.stores().length);
        assertEquals(initialRobotsCount, s.robots().length);
        assertTrue(s.ok());
    }
}
