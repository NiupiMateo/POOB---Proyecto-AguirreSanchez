package silkRoad;

import java.util.Scanner;

public class SilkRoadATest {
    private static Scanner sc = new Scanner(System.in);

    public static void testVisualScenario1() {
        SilkRoad r = new SilkRoad(10);
        r.makeVisible();

        r.placeStore("fighter", 4, 60);
        r.placeRobot("tender", 2);
        r.moveRobots();

        System.out.println("Verifique visualmente:");
        System.out.println(" Tienda fighter (gris si no fue vaciada)");
        System.out.println(" Robot tender tomó solo la mitad del dinero");
        System.out.print("¿Acepta el resultado visual? (s/n): ");
        String resp = sc.nextLine();
        System.out.println(resp.equalsIgnoreCase("s") ? "Aceptado" : "Rechazado");
    }

    public static void testVisualScenario2() {
        SilkRoad r = new SilkRoad(12);
        r.makeVisible();

        r.placeStore("autonomous", 3, 40);
        r.placeRobot("neverback", 1);
        r.moveRobot(1, 2);
        r.moveRobot(3, -1);

        System.out.println("Verifique visualmente:");
        System.out.println("Tienda autónoma se ubicó aleatoriamente");
        System.out.println("Robot neverback no retrocede");
        System.out.print("¿Acepta el resultado visual? (s/n): ");
        String resp = sc.nextLine();
        System.out.println(resp.equalsIgnoreCase("s") ? "Aceptado" :  "Rechazado");
    }
}