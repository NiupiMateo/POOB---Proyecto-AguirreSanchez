package silkRoad;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class SilkRoadCC4Test {
    private SilkRoad r;

    @Before
    public void setUp() {
        r = new SilkRoad(12);
    }

    @Test
    public void testCollectiveScenario() {
        r.placeStore("normal", 3, 40);
        r.placeStore("autonomous", 5, 30);
        r.placeStore("fighter", 8, 50);

        r.placeRobot("normal", 2);
        r.placeRobot("neverback", 6);
        r.placeRobot("tender", 10);

        r.moveRobots();

        int profit = r.profit();
        assertTrue("Debe haber ganancias totales positivas", profit > 0);

        int[][] tiendas = r.stores();
        int vacias = 0;
        for (int[] t : tiendas) {
            if (t[1] == 0) vacias++;
        }

        assertTrue("Al menos una tienda debería vaciarse", vacias >= 1);
    }
}