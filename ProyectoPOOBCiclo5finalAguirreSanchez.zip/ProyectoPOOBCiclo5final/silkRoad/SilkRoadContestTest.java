package silkRoad;

import org.junit.Test;
import static org.junit.Assert.*;

public class SilkRoadContestTest {

    @Test
    public void testSolve_EmptyDays_ReturnsEmptyArray() {
        SilkRoadContest contest = new SilkRoadContest();
        int[][] days = new int[0][];
        int[] result = contest.solve(days);
        assertEquals(0, result.length);
    }

    @Test
    public void testSolve_SamePosRobotStore_PositiveProfit() {
        SilkRoadContest contest = new SilkRoadContest();
        int[][] days = { {1, 10}, {2, 10, 5} };
        int[] result = contest.solve(days);
        assertArrayEquals(new int[]{0, 5}, result);
    }

    @Test
    public void testSolve_ICPCLikeSequence_Cumulative() {
        SilkRoadContest contest = new SilkRoadContest();
        int[][] days = {
            {1, 20},
            {2, 15, 15},
            {2, 40, 50},
            {1, 50},
            {2, 80, 20},
            {2, 70, 30}
        };
        int[] expected = {0, 10, 40, 50, 50, 60};
        int[] result = contest.solve(days);
        assertArrayEquals(expected, result);
    }

    @Test(expected = NullPointerException.class)
    public void testSolve_NullDays_ThrowsNPE() {
        SilkRoadContest contest = new SilkRoadContest();
        contest.solve(null);
    }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
    public void testSolve_Type2MissingCoins_ThrowsAIOOBE() {
        SilkRoadContest contest = new SilkRoadContest();
        int[][] days = { {2, 10} };
        contest.solve(days);
    }

    @Test(expected = NullPointerException.class)
    public void testSimulate_NullDays_ThrowsNPE() {
        SilkRoadContest contest = new SilkRoadContest();
        contest.simulate(null, false);
    }
}
