package silkRoad;
import shapes.*;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Clase principal del simulador de la Ruta de la Seda
 * 
 * Esta clase maneja:
 * - Crear la ruta con el tamaño que se quiera
 * - Poner y quitar tiendas, y reabastecerlas
 * - Poner y quitar robots, y devolverlos a donde empezaron
 * - Hacer que los robots se muevan
 * - Reiniciar todo pero manteniendo la configuración
 * - Ver cuántos tenges se ha ganado
 * - Mostrar o esconder el canvas   
 * 
 * @author Camilo Aguirre- Mateo Sanchez
 * @version 28-09-2025
 */
public class SilkRoad {
    private int length; 
    private List<Store> stores; 
    private List<Robot> robots; 
    private int profit; 
    private boolean visible;
    private boolean lastOk; 

    private Rectangle profitBar; 
    private Rectangle profitBackground;
    
    private static final int CELL_SIZE = 30; // tamaño de cada cuadrito en la espiral
    private static final int CENTER_X = 150; // donde empieza la espiral en X
    private static final int CENTER_Y = 150; // donde empieza la espiral en Y
    private String[] colors = {"red","blue","green","yellow","magenta","black","white"};
    private int colorIndex; // para ir dando un color diferente a cada cosa que se crea
    
    /**
     * Constructor que crea una ruta de seda con la longitud dada
     * 
     * Aquí se inicializa todo desde cero:
     * - borra tiendas y robots
     * - resetea las ganancias
     * - arranca los colores desde el principio
     * 
     * Si el tamaño <= 0, marca error y ok() queda en false
     * Si está todo bien, crea la ruta y ok() queda en true
     *
     * @param length cuántas posiciones va a tener la ruta (tiene que ser mayor que 0)
     */
    public SilkRoad(int length) {
        stores = new ArrayList<>();
        robots = new ArrayList<>();
        profit = 0;
        visible = true;  
        colorIndex = 0;

        try {
            if (length <= 0) {
                throw new SilkRoadException.RouteExceptions(
                    SilkRoadException.RouteExceptions.INVALID_LENGTH + 
                    " (se recibió: " + length + ")"
                );
            }
            this.length = length;
            lastOk = true;
        } catch (SilkRoadException.RouteExceptions e) {
            fail(e);
            this.length = 0;
        }

        if (visible) {
            redraw();
        }
    }

    /**
     * Constructor que crea la ruta usando los datos del problema
     * 
     * @param days matriz con los datos así:
     *             - [1, x] significa poner un robot en posición x
     *             - [2, x, c] significa poner tienda en posición x con c tenges
     * 
     * Lo que hace:
     * - Calcula el tamaño de la ruta viendo cuál es la posición más grande
     * - Va poniendo robots y tiendas según lo que diga la matriz
     * - Si todo sale bien, ok() queda en true
     */
    public SilkRoad(int[][] days) {
        stores = new ArrayList<>();
        robots = new ArrayList<>();
        profit = 0;
        visible = true;
        lastOk = true;
        colorIndex = 0;
        
        try {
            // 1. Calcula longitud máxima
            int maxPos = 0;
            for (int[] d : days) {
                if (d.length > 1 && d[1] > maxPos) {
                    maxPos = d[1];
                }
            }
            
            if (maxPos < 0) {
                throw new SilkRoadException.RouteExceptions(
                    SilkRoadException.RouteExceptions.INVALID_DAYS + 
                    ": La entrada no contiene los datos válidos"
                );
            }
            
            length = maxPos + 1;
            
            // 2. Procesa los días
            for (int[] d : days) {
                if (d[0] == 1) { // robot
                    placeRobot(d[1]);
                } else if (d[0] == 2) { // tienda
                    if (d.length < 3) {
                        throw new SilkRoadException.RouteExceptions(
                            SilkRoadException.RouteExceptions.INVALID_DAYS + 
                            ": Faltan datos para la tienda en entrada"
                        );
                    }
                    placeStore(d[1], d[2]);
                } else {
                    throw new SilkRoadException.RouteExceptions(
                        SilkRoadException.RouteExceptions.INVALID_DAYS + 
                        ": Tipo de día inválido " + d[0]
                    );
                }
            }
            
            for (Store s : stores) {
                if (s != null) {
                    s.updateAppearance();
                }
            }
                
            if (visible) redraw();
            
            blinkTopRobot();
        
            if (visible) redraw();
            lastOk = true;
            
        } catch (SilkRoadException.RouteExceptions e) {
            fail(e);
        }
    }
    
    /**
     * Mueve todos los robots para que ganen lo máximo posible
     * 
     * Para cada robot:
     * - busca la tienda que más le convenga (tenges - distancia)
     * - si esa tienda le da ganancia positiva, se mueve para allá
     * - suma los tenges ganados al robot y al total
     * - deja la tienda vacía
     */
    public void moveRobots() {
        for (Robot robot : robots) {
            if (robot == null) continue;
            Store bestStore = null;
            int bestGain = Integer.MIN_VALUE;
            // Busca la mejor tienda para este robot
            for (Store store : stores) {
                if (store == null || store.isEmpty()) continue;
                int distance = Math.abs(robot.getLocation() - store.getLocation());
                int gain = store.getTenges() - distance;
                if (gain > bestGain) {
                    bestGain = gain;
                    bestStore = store;
                }
            }
            // Mueve si hay ganancia positiva
            if (bestStore != null && bestGain > 0) {
                robot.moveToLocation(bestStore.getLocation());  
                robot.addProfit(bestGain);                      
                profit += bestGain;
                bestStore.empty();
                } else {
                //no se mueve
                fail(new SilkRoadException.RobotExceptions(
                    SilkRoadException.RobotExceptions.NO_MOVEMENT + 
                    ": Robot en posición " + robot.getLocation() + " no se movió (sin ganancia positiva)"
                ));
            }
        }
    
        lastOk = true;
        if (visible) redraw();
    }
    
    
    /**
     * Hace que parpadee el robot que más tenges ganados
     * 
     * Primero busca cuál robot tiene más ganancia total
     * Después lo hace parpadear 3 veces (prende y apaga) para que se note
     * 
     * Si no hay robots o el robot no tiene figura no hace nada
     */
    public void blinkTopRobot() {
        if (countRobots() == 0) return;
        // Busca el robot con mayor ganancia
        Robot topRobot = null;
        for (Robot robot : robots) {
            if (robot != null) {
                if (topRobot == null || robot.getTotalProfit() > topRobot.getTotalProfit()) {
                    topRobot = robot;
                }
            }
        }
        
        if (topRobot == null) return;

        Circle robotCircle = topRobot.getCircle();
        if (robotCircle == null) return;

        Canvas canvas = Canvas.getCanvas();
        for (int i = 0; i < 3; i++) {
            topRobot.setVisible(false);
            canvas.wait(300);
            topRobot.setVisible(true);
            canvas.wait(300);
        }
    }
    
    /**
     * Devuelve una matriz con info de las tiendas que se han vaciado
     * Cada fila es [ubicacion, cuantas_veces_se_vacio]
     * 
     * La ordena de menor a mayor por ubicación usando el algoritmo bubble sort
     */
    public int[][] emptiedStores() {
        int n = countStores();
        int[][] result = new int[n][2];
        // Llena la matriz con datos de cada tienda
        int index = 0;
        for (Store store : stores) {
            if (store != null) {
                result[index][0] = store.getLocation();
                result[index][1] = store.getTimesEmptied();
                index++;
            }
        }
    
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (result[j][0] > result[j + 1][0]) {
                    int tempLoc = result[j][0];
                    int tempTimes = result[j][1];
                    result[j][0] = result[j + 1][0];
                    result[j][1] = result[j + 1][1];
                    result[j + 1][0] = tempLoc;
                    result[j + 1][1] = tempTimes;
                }
            }
        }
        return result;
    }
    
    /**
     * Devuelve una matriz con las ganancias de cada robot por movimiento
     * 
     * Cada fila es así: [ id_robot, ganancia_mov1, ganancia_mov2, ... ]
     * 
     * Si un robot no se ha movido, sólo sale su id
     */
    public int[][] profitPerMove() {
        int numRobots = countRobots();
        // Determina el número máximo de movimientos hechos por cualquier robot
        int maxMoves = 0;
        for (Robot robot : robots) {
            if (robot != null) {
                int moves = robot.getProfitsPerMove().size();
                if (moves > maxMoves) {
                    maxMoves = moves;
                }
            }
        }
    
        // Crea matriz [robots][1 + maxMoves]
        int[][] result = new int[numRobots][1 + maxMoves];
    
        // Llena con id y las ganancias
        int index = 0;
        for (Robot robot : robots) {
            if (robot != null) {
                result[index][0] = robot.getId();
    
                for (int j = 0; j < robot.getProfitsPerMove().size(); j++) {
                    result[index][1 + j] = robot.getProfitsPerMove().get(j);
                }
                index++;
            }
        }
        return result;
    }

    
    /**
     * Pone una tienda nueva en la posición dada 
     * Verifica que:
     * - la ruta exista
     * - la posición sea válida
     * - los tenges no sean negativos
     * - no haya otra tienda en la misma pos
     * 
     * @param location dónde poner la tienda (de 1 a length)
     * @param tenges dinero inicial de la tienda (tiene que ser >= 0)
     */
    public void placeStore(int location, int tenges) {
        try {
            if (!isRouteCreated()) {
                throw new SilkRoadException.RouteExceptions(
                    SilkRoadException.RouteExceptions.ROUTE_NOT_CREATED
                );
            }
            
            if (!isValidLocation(location)) {
                throw new SilkRoadException.LocationExceptions(
                    SilkRoadException.LocationExceptions.INVALID_LOCATION + 
                    ": " + location + " (debe estar entre 1 y " + length + ")"
                );
            }
            
            if (tenges < 0) {
                throw new SilkRoadException.StoreExceptions(
                    SilkRoadException.StoreExceptions.INVALID_TENGES + 
                    " (se recibió: " + tenges + ")"
                );
            }
            
            for (Store store : stores) {
                if (store != null && store.getLocation() == location) {
                    throw new SilkRoadException.StoreExceptions(
                        SilkRoadException.StoreExceptions.STORE_ALREADY_EXISTS + 
                        " en la ubicación " + location
                    );
                }
            }
            
            // Agrega la tienda a la lista
            stores.add(new Store(countStores() + 1, location, tenges, nextColor()));
            if (visible) {
                redraw();
            }
            lastOk = true;
            
        } catch (SilkRoadException.RouteExceptions | 
                 SilkRoadException.LocationExceptions | 
                 SilkRoadException.StoreExceptions e) {
            fail(e);
        }
    }
    
    /**
     * Pone una tienda con tipo específico
     * 
     * Tipos que hay:
     * - "normal": da toda sus tenges al robot
     * - "autonomous": se pone sola en un lugar libre (ignora location)
     * - "fighter": sólo le dan tenges a robots que tengan más tenges que ella
     * - "trap": le quita tenges al robot (20% de lo que tenga)
     * 
     * @param type qué tipo de tienda es
     * @param location dónde ponerla (si es autonomous no importa)
     * @param tenges inicial
     */
    public void placeStore(String type, int location, int tenges) {
        try {
            if (!isRouteCreated()) {
                throw new SilkRoadException.RouteExceptions(
                    SilkRoadException.RouteExceptions.ROUTE_NOT_CREATED
                );
            }
            
            if (tenges < 0) {
                throw new SilkRoadException.StoreExceptions(
                    SilkRoadException.StoreExceptions.INVALID_TENGES + 
                    " (se recibió: " + tenges + ")"
                );
            }
            
            int finalLocation = location;
            
            //Autonomus busca la ubicación libre aleatoriamente
            if (type.equals("autonomous")) {
                finalLocation = findRandomFreeLocation();
                if (finalLocation == -1) {
                    throw new SilkRoadException.StoreExceptions(
                        SilkRoadException.StoreExceptions.NO_FREE_LOCATION
                    );
                }
            } else {
                // Para normal, fighter y trap: validar ubicación indicada
                if (!isValidLocation(location)) {
                    throw new SilkRoadException.LocationExceptions(
                        SilkRoadException.LocationExceptions.INVALID_LOCATION + 
                        ": " + location + " (debe estar entre 1 y " + length + ")"
                    );
                }
                
                // Verifica que no haya tienda en esa ubicación
                for (Store store : stores) {
                    if (store != null && store.getLocation() == finalLocation) {
                        throw new SilkRoadException.StoreExceptions(
                            SilkRoadException.StoreExceptions.STORE_ALREADY_EXISTS + 
                            " en la ubicación " + finalLocation
                        );
                    }
                }
            }
            
            // Agrega tienda a la lista
            stores.add(new Store(countStores() + 1, finalLocation, tenges, nextColor(), type));
            if (visible) {
                redraw();
            }
            lastOk = true;
            
        } catch (SilkRoadException.RouteExceptions | 
                 SilkRoadException.LocationExceptions | 
                 SilkRoadException.StoreExceptions e) {
            fail(e);
        }
    }
    
    /**
     * Quita la tienda que esté en esa posición
     * 
     * Busca la tienda y la borra
     * Si tiene figura en el canvas, primero la esconde
     * 
     * @param location dónde está la tienda que se quiere quitar
     */
    public void removeStore(int location) {
        try {
            for (int i = 0; i < stores.size(); i++) {
                Store store = stores.get(i);
                if (store != null && store.getLocation() == location) {
                    // Oculta figura si está visible
                    if (store.getRectangle() != null) {
                        store.getRectangle().makeInvisible();
                    }
                    // Elimina de la lista
                    stores.remove(i);
                    if (visible) {
                        redraw();
                    }
                    lastOk = true;
                    return;
                }
            }        
            throw new SilkRoadException.StoreExceptions(
                SilkRoadException.StoreExceptions.STORE_NOT_FOUND + 
                " en la ubicación " + location
            );
        } catch (SilkRoadException.StoreExceptions e) {
            fail(e);
        }
    }
    
    /**
     * Reabastece todas las tiendas con lo que tenían al principio
     * 
     * Les devuelve a todas los tenges iniciales que tenían cuando se crearon
     */
    public void resupplyStores() {
        for (Store store : stores) {
            if (store != null) {
                store.resupply();
            }
        }
        if (visible) {
            redraw();
        }
        lastOk = true;
    }

    /**
     * Pone un robot nuevo en la posición dada
     * 
     * Chequea que:
     * - la ruta exista
     * - la posición sea válida
     * - no haya otro robot que empiece en esa misma posición
     * 
     * @param location dónde empieza el robot (de 1 a length)
     */
    public void placeRobot(int location) {
        try {
            if (!isRouteCreated()) {
                throw new SilkRoadException.RouteExceptions(
                    SilkRoadException.RouteExceptions.ROUTE_NOT_CREATED
                );
            }
            
            if (!isValidLocation(location)) {
                throw new SilkRoadException.LocationExceptions(
                    SilkRoadException.LocationExceptions.INVALID_LOCATION + 
                    ": " + location + " (debe estar entre 1 y " + length + ")"
                );
            }
        
            for (Robot robot : robots) {
                if (robot != null && robot.getInitialLocation() == location) {
                    throw new SilkRoadException.RobotExceptions(
                        SilkRoadException.RobotExceptions.ROBOT_ALREADY_EXISTS + 
                        " en la ubicación inicial " + location
                    );
                }
            }

            // Agrega robot a la lista
            robots.add(new Robot(countRobots() + 1, location, nextColor()));
            if (visible) {
                redraw();
            }
            lastOk = true;
            
        } catch (SilkRoadException.RouteExceptions | 
                 SilkRoadException.LocationExceptions | 
                 SilkRoadException.RobotExceptions e) {
            fail(e);
        }
    }

    /**
     * Quita el robot que esté en esa posición
     * 
     * Busca el robot y lo borra
     * Si tiene figura en el canvas, primero la esconde
     * 
     * @param location dónde está el robot que se quiere quitar
     */
    public void removeRobot(int location) {
        try {
            for (int i = 0; i < robots.size(); i++) {
                Robot robot = robots.get(i);
                if (robot != null && robot.getLocation() == location) {
                    // Oculta figura si está visible
                    if (robot.getCircle() != null) {
                        robot.getCircle().makeInvisible();
                    }
                    // Elimina de la lista
                    robots.remove(i);
                    if (visible) {
                        redraw();
                    }
                    lastOk = true;
                    return;
                }
            }
            throw new SilkRoadException.RobotExceptions(
                SilkRoadException.RobotExceptions.ROBOT_NOT_FOUND + 
                " en la ubicación " + location
            );
        } catch (SilkRoadException.RobotExceptions e) {
            fail(e);
        }
    }
    
    /**
     * Pone un robot con tipo específico
     * 
     * Tipos que hay:
     * - "normal": agarra toda los tenges de las tiendas
     * - "neverback": nunca retrocede
     * - "tender": sólo toma la mitad de lo que tiene la tienda
     * - "dummy": no ganan tenges (como si estuviera dañado)
     * 
     * @param type qué tipo de robot es
     * @param location dónde empieza el robot
     */
    public void placeRobot(String type, int location) {
        try {
            if (!isRouteCreated()) {
                throw new SilkRoadException.RouteExceptions(
                    SilkRoadException.RouteExceptions.ROUTE_NOT_CREATED
                );
            }
            
            if (!isValidLocation(location)) {
                throw new SilkRoadException.LocationExceptions(
                    SilkRoadException.LocationExceptions.INVALID_LOCATION + 
                    ": " + location + " (debe estar entre 1 y " + length + ")"
                );
            }
        
            for (Robot robot : robots) {
                if (robot != null && robot.getInitialLocation() == location) {
                    throw new SilkRoadException.RobotExceptions(
                        SilkRoadException.RobotExceptions.ROBOT_ALREADY_EXISTS + 
                        " en la ubicación inicial " + location
                    );
                }
            }

            // Agrega robot a la lista
            robots.add(new Robot(countRobots() + 1, location, nextColor(), type));
            if (visible) {
                redraw();
            }
            lastOk = true;
            
        } catch (SilkRoadException.RouteExceptions | 
                 SilkRoadException.LocationExceptions | 
                 SilkRoadException.RobotExceptions e) {
            fail(e);
        }
    }
    
    /**
     * Devuelve todos los robots a donde empezaron
     * 
     * Cada robot regresa a la posición donde se puso al principio con placeRobot
     */
    public void returnRobots() {
        for (Robot robot : robots) {
            if (robot != null) {
                robot.reset();
            }
        }
        if (visible) {
            redraw();
        }
        lastOk = true;
    }


    /**
     * Mueve un robot que esté en cierta posición
     * 
     * Lo que hace:
     * 1. Busca el robot en esa posición
     * 2. Calcula la nueva posición (location + meters)
     * 3. Verifica que la nueva posición sea válida
     * 4. Verifica que no haya otro robot ahí
     * 5. Mueve el robot
     * 6. Si hay tienda ahí, recoge los tenges
     * 
     * @param location dónde está el robot ahorita
     * @param meters cuánto se va a mover (puede ser negativo para atrás)
     */
    public void moveRobot(int location, int meters) {
        try {
            // Busca robot en la posición (primero si hay varios)
            Robot robotToMove = null;
            for (Robot robot : robots) {
                if (robot != null && robot.getLocation() == location) {
                    robotToMove = robot;
                    break;  // Toma el primero según requisito de diseño
                }
            }

            // Valida que existe robot
            if (robotToMove == null) {
                throw new SilkRoadException.RobotExceptions(
                    SilkRoadException.RobotExceptions.ROBOT_NOT_FOUND + 
                    " en la ubicación " + location
                );
            }

            // Neverback no puede retroceder
            if (robotToMove.getType().equals("neverback") && meters < 0) {
                throw new SilkRoadException.RobotExceptions(
                    SilkRoadException.RobotExceptions.INVALID_MOVEMENT + 
                    ": El robot NeverBack no puede retroceder (meters=" + meters + ")"
                );
            }

            // Calcula nueva posición
            int newLocation = robotToMove.getLocation() + meters;
            if (!isValidLocation(newLocation)) {
                throw new SilkRoadException.LocationExceptions(
                    SilkRoadException.LocationExceptions.INVALID_LOCATION + 
                    ": " + newLocation + " (debe estar entre 1 y " + length + ")"
                );
            }

            // Valida que no haya colisión con otro robot
            for (Robot robot : robots) {
                if (robot != null && robot != robotToMove && robot.getLocation() == newLocation) {
                    throw new SilkRoadException.RobotExceptions(
                        SilkRoadException.RobotExceptions.ROBOT_COLLISION + 
                        " en la ubicación " + newLocation
                    );
                }
            }
            //Ejecuta movimiento
            robotToMove.moveToLocation(newLocation);
            for (Store store : stores) {
                if (store != null && store.getLocation() == newLocation && !store.isEmpty()) {
                    int collected = 0;
                    // Figther solo cede a robots ricos
                    if (store.getType().equals("fighter")) {
                        if (robotToMove.getMoney() > store.getTenges()) {
                            // Si el Robot tiene más tenges, puede tomar
                            collected = calculateCollection(robotToMove, store);
                        } else {
                            //no recibe nada
                            collected = 0;
                        }
                    } else {
                        // Otras tiendas (normal, autonomous, trap)
                        collected = calculateCollection(robotToMove, store);
                    }
                    
                    // Actualizar saldos
                    if (collected > 0) {
                        // Robot gana tenges (tiendas normal, autonomous, fighter)
                        store.withdraw(collected);
                        robotToMove.addMoney(collected);
                        profit = profit + collected;
                    } else if (collected < 0) {
                        // Robot pierde tenges TrapStore
                        int loss = -collected; // convierte a positivo
                        robotToMove.subtractMoney(loss);
                        profit = profit - loss;
                    }
                    // Si collected == 0: dummy robot o fighter rechaza
                    break;
                }
            }
            
            if (visible) {
                redraw();
            }
            lastOk = true;
        } catch (SilkRoadException.RobotExceptions | 
                 SilkRoadException.LocationExceptions e) {
            fail(e);
        }
    }
    
    /**
     * Reinicia todo pero deja la configuración igual
     * 
     * Hace:
     * - pone las ganancias en 0
     * - reabastece las tiendas
     * - devuelve los robots a dónde empezaron
     * - pero no borra nada, todo queda configurado igual
     */
    public void reboot() {
        profit = 0;
        resupplyStores();
        returnRobots();
        if (visible) {
            redraw();
        }
        lastOk = true;
    }
    
    /**
     * Devuelve cuántos tenges se ha ganado en total
     * 
     * Los tenges se suman cuando los robots pasan por tiendas que tienen tenges
     * 
     * @return total de ganancias acumuladas
     */
    public int profit() {
        return profit;
    }

    /**
     * Devuelve las posiciones de todas las tiendas
     * 
     * @return matriz con [ubicacion, tenges] de cada tienda
     */
    public int[][] stores() {
        int count = countStores();
        int[][] result = new int[count][2];
        int index = 0;
        for (Store store : stores) {
            if (store != null) {
                result[index][0] = store.getLocation();
                result[index][1] = store.getTenges();
                index++;
            }
        }
        return result;
    }

    /**
     * Devuelve dónde están los robots ahorita
     * 
     * Las posiciones pueden ser diferentes a dónde empezaron si ya se movieron
     * 
     * @return matriz con [ubicación_actual, ganancia_total] de cada robot
     */
    public int[][] robots() {
        int count = countRobots();
        int[][] result = new int[count][2];
        int index = 0;
        for (Robot robot : robots) {
            if (robot != null) {
                result[index][0] = robot.getLocation();
                result[index][1] = robot.getTotalProfit();
                index++;
            }
        }
        return result;
    }
    
    /**
     * Hace visible el simulador
     * 
     * Cuando está visible:
     * - se ven todas las figuras
     * - todo se actualiza en el canvas
     * - los errores salen en consola
     */
    public void makeVisible() {
        visible = true;
        redraw();
    }

    /**
     * Hace invisible el simulador
     * 
     * Cuando está invisible:
     * - se esconden todas las figuras
     * - el simulador funciona pero no se ve nada
     * - no se muestran los errores
     */
    public void makeInvisible() {
        visible = false;
        for (Store s : stores) {
            if (s != null && s.getRectangle() != null) {
                s.getRectangle().makeInvisible();
            }
        }
        for (Robot r : robots) {
            if (r != null && r.getCircle() != null) {
                r.getCircle().makeInvisible();
            }
        }
        if (profitBar != null) {
            profitBar.makeInvisible();
        }
        if (profitBackground != null) {
            profitBackground.makeInvisible();
        }
    }
    
    /**
     * Termina el simulador y borra todo
     * 
     * Hace:
     * - elimina todas las tiendas y robots
     * - pone las ganancias en 0
     * - esconde todo si estaba visible
     * 
     * Deja todo limpio para empezar de nuevo
     */
    public void finish() {
        // Oculta los elementos antes de limpiar
        if (visible) {
            makeInvisible();
        }
        
        // Limpia listas
        stores.clear();
        robots.clear();
        profit = 0;
        length = 0;  
        colorIndex = 0;
        lastOk = true;
    }

    /**
     * Dice si la última operación salió bien
     * 
     * @return true si salió todo bien, false si hubo algún error
     */
    public boolean ok() {
        return lastOk;
    }
    
    /**
     * Devuelve el tamaño de la ruta
     * 
     * @return cuantas posiciones tiene la ruta (de 1 a length)
     */
    public int getLength() {
        return length;
    }

    /**
     * Actualiza el canvas sin recrear todo
     * 
     * Llama a:
     * - updateStores(): crea rectángulos sólo para tiendas nuevas
     * - updateRobots(): crea círculos para robots nuevos o mueve los que ya existen
     * - drawProfitBar(): redibuja la barra de ganancias
     * 
     * Así no parpadea tanto y es más rápido
     * Sólo se ejecuta si visible es true
     */
    public void redraw() {
        if (!visible) return;
        updateStores();
        updateRobots();
        drawProfitBar();
    }

    /**
     * Actualiza las figuras de las tiendas
     * 
     * Revisa cada tienda y si no tiene rectángulo se lo crea
     * Calcula dónde va en la espiral y lo pone ahí con su color
     * Si ya tiene rectángulo no hace nada (por eso no parpadea)
     */
    private void updateStores() {
        for (Store store : stores) {
            if (store == null) continue;
            
            Rectangle rect = store.getRectangle();
            if (rect == null) {
                // Crea nueva figura para esta tienda
                int[] pos = Spiral.getCoords(store.getLocation());
                int x = CENTER_X + pos[0] * CELL_SIZE;
                int y = CENTER_Y - pos[1] * CELL_SIZE;
                
                rect = new Rectangle();
                rect.changeSize(CELL_SIZE - 5, CELL_SIZE - 5);
                rect.changeColor(store.getColorName());
                rect.moveTo(x, y);
                rect.makeVisible();
                store.setRectangle(rect);
            }
        }
    }

    /**
     * Actualiza las figuras de los robots
     * 
     * Revisa cada robot:
     * - si no tiene círculo se lo crea con su color
     * - si ya tiene círculo sólo lo mueve a donde está el robot
     * 
     * No crea círculos nuevos cada vez, sólo los mueve (por eso no parpadea)
     */

    private void updateRobots() {
        for (Robot robot : robots) {
            if (robot == null) continue;
            
            Circle c = robot.getCircle();
            int[] pos = Spiral.getCoords(robot.getLocation());
            int x = CENTER_X + pos[0] * CELL_SIZE;
            int y = CENTER_Y - pos[1] * CELL_SIZE;
            
            if (c == null) {
                // Crea nueva figura para este robot
                c = new Circle();
                c.changeSize(CELL_SIZE - 10);
                c.changeColor(robot.getColorName());
                c.moveTo(x, y);
                c.makeVisible();
                robot.setCircle(c);
            } else {
                // Actualiza posición del robot existente
                c.moveTo(x, y);
            }
        }
    }

    /**
     * Dibuja la barra que muestra las ganancias
     * 
     * Calcula el máximo posible (profit + lo que tienen todas las tiendas)
     * Hace una barra negra de fondo de 200px
     * Encima pone una verde que es proporcional a profit
     * Así se ve cuánto se ha ganado vs cuánto se puede ganar
     */
    private void drawProfitBar() {
        int max = profit;
        for (Store s : stores) {
            if (s != null) { 
                max += s.getTenges();
            }
        }
        if (max == 0) max = 1;
        int width = 200;
        int height = 20;
        int filled = (profit * width) / max;
        profitBackground = new Rectangle();
        profitBackground.changeSize(height, width);
        profitBackground.changeColor("black");
        profitBackground.moveTo(50, 280);
        profitBackground.makeVisible();
        profitBar = new Rectangle();
        profitBar.changeSize(height, filled);
        profitBar.changeColor("green");
        profitBar.moveTo(50, 280);
        profitBar.makeVisible();
    }
    
    /** cuenta cuantas tiendas hay*/
    private int countStores() {
        return stores.size();
    }
    
    /** cuenta cuantos robots hay*/
    private int countRobots() {
        return robots.size();
    }
    
    /** verifica si ya se creo la ruta*/
    private boolean isRouteCreated() {
        if (length > 0) {
            return true;
        } else {
            return false;
        }
    }

    
    /** verifica si una ubicacion es valida (entre 1 y length)*/
    private boolean isValidLocation(int location) {
        if (location >= 1 && location <= length) {
            return true;
        } else {
            return false;
        }
    }

    
    /**
     * Busca una ubicación libre al azar donde no haya tiendas
     * 
     * Arma una lista con todas las posiciones libres
     * Escoge una al azar de esa lista
     * Si no hay ninguna libre devuelve -1
     */
    private int findRandomFreeLocation() {
        //lista de ubicaciones libres
        ArrayList<Integer> freeLocations = new ArrayList<>();
        for (int loc = 1; loc <= length; loc++) {
            boolean occupied = false;
            for (Store store : stores) {
                if (store != null && store.getLocation() == loc) {
                    occupied = true;
                    break;
                }
            }
            if (!occupied) {
                freeLocations.add(loc);
            }
        }
        // Si no hay ubicaciones libres, retorna -1
        if (freeLocations.isEmpty()) {
            return -1;
        }
        // Selecciona una ubicación aleatoria de las que esten disponibles
        Random random = new Random();
        int randomIndex = random.nextInt(freeLocations.size());
        return freeLocations.get(randomIndex);
    }
    
    /**
     * Calcula cuantos tenges recoge o pierde un robot al visitar una tienda
     * Depende del tipo de robot y tipo de tienda
     * 
     * @return positivo si gana, negativo si pierde, 0 si no pasa nada
     */
    private int calculateCollection(Robot robot, Store store) {
        // Dummy Robot nunca gana tenges
        if (robot.getType().equals("dummy")) {
            return 0;
        }
        int available = store.getTenges();
        // Trap Store hace perder 20% de tenges del robot 
        if (store.getType().equals("trap")) {
            int loss = (int) (robot.getMoney() * store.getTrapFactor());
            return -loss; // negativo = pérdida
        }
        // Tender Robot toma la mitad de tenges
        if (robot.getType().equals("tender")) {
            return available / 2;
        }
        // Normal y Neverback toman todo
        return available;
    }
    
    /**
     * Registra un error y lo muestra si está visible
     * 
     * Pone lastOk en false
     * Si está visible muestra el error en consola y en un popup
     * Si está invisible sólo registra el error sin mostrar nada
     */
    private void fail(Exception e) {
        lastOk = false;
        if (visible) {
            String mensaje = e.getMessage();
            System.out.println("ERROR: " + mensaje);
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, mensaje, "Excepción - SilkRoad", JOptionPane.ERROR_MESSAGE);
        }
    }

    /** 
    * Da el siguiente color de la lista
    * cuando llega al final vuelve a empezar
    */
    private String nextColor() {
        String c = colors[colorIndex];
        colorIndex = (colorIndex + 1) % colors.length;
        return c;
    }
}