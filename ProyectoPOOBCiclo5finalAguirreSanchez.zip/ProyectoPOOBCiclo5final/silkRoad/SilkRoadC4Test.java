package silkRoad;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class SilkRoadC4Test {
    private SilkRoad r;

    @Before
    public void setUp() {
        r = new SilkRoad(10);
    }

    @Test
    public void testAutonomousStoreRandomLocation() {
        r.placeStore("autonomous", 3, 50);
        int[][] tiendas = r.stores();
        assertTrue("Debe ubicarse en un rango válido", tiendas[0][0] >= 1 && tiendas[0][0] <= 10);
    }

    @Test
    public void testFighterStoreRestriction() {
        r.placeStore("fighter", 5, 50);
        r.placeRobot("normal", 5);
        r.moveRobot(5, 0);
        int[][] tiendas = r.stores();
        assertTrue("La tienda fighter no debe vaciarse si el robot tiene menos dinero", tiendas[0][1] > 0);
    }

    @Test
    public void testTenderRobotTakesHalf() {
        r.placeStore("normal", 6, 100);
        r.placeRobot("tender", 5);
        r.moveRobot(5, 1);
        int profit = r.profit();
        assertEquals("El tender debe tomar la mitad (50)", 50, profit);
    }

    @Test
    public void testNeverbackRobotNoBackwards() {
        r.placeRobot("neverback", 3);
        r.moveRobot(3, 2);
        int posForward = r.robots()[0][0];
        r.moveRobot(posForward, -1);
        int posAfter = r.robots()[0][0];
        assertTrue("El robot neverback no debe retroceder", posAfter >= posForward);
    }
}