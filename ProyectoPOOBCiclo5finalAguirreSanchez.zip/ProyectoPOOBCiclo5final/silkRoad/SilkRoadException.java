package silkRoad;

/**
 * Esta clase contiene todas las excepciones que se usan en la clase SilkRoad y SilkRoadContest.
 * Organizadas por categorías para manejar diferentes tipos de errores en la simulación.
 * 
 * @author Camilo Aguirre
 * @author Mateo Sanchez
 * @version 2025
 */
public class SilkRoadException extends Exception {
    
    /**
     * Excepciones relacionadas con la creación e inicialización de la ruta.
     */
    public static class RouteExceptions extends Exception {
        public static final String ROUTE_NOT_CREATED = "Debe crear una ruta primero usando el constructor SilkRoad(length)";
        public static final String INVALID_LENGTH = "La longitud de la ruta debe ser mayor a 0";
        public static final String INVALID_DAYS = "Los datos de entrada para el arreglo de días son inválidos";
        
        public RouteExceptions(String message) {
            super(message);
        }
    }
    
    /**
     * Excepciones relacionadas con la validación de ubicación y posición.
     */
    public static class LocationExceptions extends Exception {
        public static final String INVALID_LOCATION = "Ubicación inválida. Debe estar dentro de los límites de la ruta";
        public static final String OUT_OF_BOUNDS = "La posición está fuera de los límites de la ruta";
        public static final String NEGATIVE_POSITION = "La posición no puede ser negativa";
        
        public LocationExceptions(String message) {
            super(message);
        }
    }
    
    /**
     * Excepciones relacionadas con las operaciones de tiendas (agregar, eliminar, reabastecer).
     */
    public static class StoreExceptions extends Exception {
        public static final String INVALID_TENGES = "Los tenges deben ser no negativos";
        public static final String STORE_ALREADY_EXISTS = "Ya existe una tienda en esta ubicación";
        public static final String STORE_NOT_FOUND = "No se encontró ninguna tienda en la ubicación especificada";
        public static final String NO_FREE_LOCATION = "No hay ubicaciones libres disponibles para la tienda autónoma";
        public static final String INVALID_STORE_TYPE = "Tipo de tienda inválido. Tipos aceptados: normal, autonomous, fighter, trap";
        
        public StoreExceptions(String message) {
            super(message);
        }
    }
    
    /**
     * Excepciones relacionadas con las operaciones de robots (agregar, eliminar, mover).
     */
    public static class RobotExceptions extends Exception {
        public static final String ROBOT_ALREADY_EXISTS = "Ya existe un robot con esta ubicación inicial";
        public static final String ROBOT_NOT_FOUND = "No se encontró ningún robot en la ubicación especificada";
        public static final String INVALID_MOVEMENT = "Movimiento inválido para este tipo de robot";
        public static final String ROBOT_COLLISION = "No se puede mover el robot a una posición ocupada";
        public static final String INVALID_ROBOT_TYPE = "Tipo de robot inválido. Tipos aceptados: normal, neverback, tender, dummy";
        public static final String NO_MOVEMENT = "El robot no puede moverse (no hay ganancia positiva disponible)";
        
        public RobotExceptions(String message) {
            super(message);
        }
    }
    
    /**
     * Excepciones relacionadas con el estado y operaciones de la simulación.
     */
    public static class SimulationExceptions extends Exception {
        public static final String NO_ROBOTS = "No hay robots disponibles en la simulación";
        public static final String NO_STORES = "No hay tiendas disponibles en la simulación";
        public static final String INVALID_STATE = "Estado de simulación inválido";
        
        public SimulationExceptions(String message) {
            super(message);
        }
    }
    
    /**
     * Constructor general para excepciones personalizadas.
     */
    public SilkRoadException(String message) {
        super(message);
    }
}
