package silkRoad;

import org.junit.Test;
import static org.junit.Assert.*;

public class SilkRoadContestCTest {

    @Test
    public void accordingASShouldAccumulateProfitsPerDay() {
        SilkRoadContest contest = new SilkRoadContest();
        int[][] days = {
            {1, 5},
            {2, 6, 10},
            {2, 10, 20},
            {1, 15},
            {2, 18, 25}
        };
        int[] result = contest.solve(days);
        assertEquals(days.length, result.length);
        for (int r : result) assertTrue(r >= 0);
    }

    @Test
    public void accordingASShouldReturnZeroWhenOnlyRobotsOrOnlyStores() {
        SilkRoadContest contest = new SilkRoadContest();
        int[][] onlyRobots = { {1, 3}, {1, 8}, {1, 13} };
        int[][] onlyStores  = { {2, 5, 7}, {2, 9, 12} };
        int[] r1 = contest.solve(onlyRobots);
        int[] r2 = contest.solve(onlyStores);
        for (int v : r1) assertEquals(0, v);
        for (int v : r2) assertEquals(0, v);
    }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
    public void accordingASShouldThrowWhenType2LacksCoins() {
        SilkRoadContest contest = new SilkRoadContest();
        int[][] days = { {2, 10} };
        contest.solve(days);
    }

    @Test(expected = NullPointerException.class)
    public void accordingASShouldThrowOnNullDaysInput() {
        SilkRoadContest contest = new SilkRoadContest();
        contest.solve(null);
    }
}
