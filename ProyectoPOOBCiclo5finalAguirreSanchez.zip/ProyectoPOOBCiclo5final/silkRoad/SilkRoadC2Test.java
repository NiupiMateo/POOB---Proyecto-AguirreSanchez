package silkRoad;

import org.junit.Test;
import static org.junit.Assert.*;

public class SilkRoadC2Test {

    private int[][] sampleDays() {
        return new int[][] {
            {1, 20},
            {2, 15, 15},
            {2, 40, 50},
            {1, 50},
            {2, 80, 20},
            {2, 70, 30}
        };
    }

    private int countEmptied(int[][] locTimes) {
        int c = 0;
        for (int[] row : locTimes) if (row[1] > 0) c++;
        return c;
    }

    @Test
    public void shouldCreateFromDays_setsLengthAndEntities() {
        int[][] days = sampleDays();
        SilkRoad s = new SilkRoad(days);
        s.makeInvisible();

        assertTrue(s.ok());
        assertEquals(81, s.getLength());
        assertEquals(2, s.robots().length);
        assertEquals(4, s.stores().length);
    }

    @Test
    public void shouldMoveRobots_increasesProfitAndEmptiesStore() {
        SilkRoad s = new SilkRoad(sampleDays());
        s.makeInvisible();

        int before = s.profit();
        s.moveRobots();
        int after = s.profit();

        assertTrue(after > before);

        int[][] empties = s.emptiedStores();
        assertTrue("Debe vaciar al menos una tienda", countEmptied(empties) >= 1);
    }

    @Test
    public void shouldReturnProfitPerMove_matrixStartsWithIds() {
        SilkRoad s = new SilkRoad(sampleDays());
        s.makeInvisible();
        s.moveRobots();

        int[][] m = s.profitPerMove();
        assertEquals(s.robots().length, m.length);

        int n = s.robots().length;
        boolean[] seen = new boolean[n + 1];
        for (int i = 0; i < m.length; i++) {
            int id = m[i][0];
            assertTrue("Id de robot fuera de rango", id >= 1 && id <= n);
            seen[id] = true;
        }
        for (int id = 1; id <= n; id++) {
            assertTrue("Falta el id " + id + " en la primera columna", seen[id]);
        }
    }

    @Test
    public void shouldFailPlaceStore_outOfBounds() {
        SilkRoad s = new SilkRoad(50);
        s.makeInvisible();

        s.placeStore(0, 10);
        assertFalse(s.ok());
        assertEquals(0, s.stores().length);

        s = new SilkRoad(50);
        s.makeInvisible();
        s.placeStore(51, 10);
        assertFalse(s.ok());
        assertEquals(0, s.stores().length);
    }

    @Test
    public void shouldFailPlaceRobot_duplicateInitialLocation() {
        SilkRoad s = new SilkRoad(10);
        s.makeInvisible();

        s.placeRobot(5);
        assertTrue(s.ok());
        assertEquals(1, s.robots().length);

        s.placeRobot(5);
        assertFalse(s.ok());
        assertEquals(1, s.robots().length);
    }

    @Test
    public void shouldFailMoveRobot_outsideRoute() {
        SilkRoad s = new SilkRoad(5);
        s.makeInvisible();

        s.placeRobot(1);
        assertTrue(s.ok());
        assertEquals(1, s.robots().length);
        assertEquals(1, s.robots()[0][0]); // ubicación = 1

        s.moveRobot(1, -2);
        assertFalse(s.ok());
        assertEquals("La posición debe permanecer en 1", 1, s.robots()[0][0]);
    }
}
