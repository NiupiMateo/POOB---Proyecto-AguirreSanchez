package silkRoad;

import shapes.*;
import java.util.ArrayList;

/**
 * Representa un robot dentro del simulador de la Ruta de la Seda.
 *
 * Cada robot:
 * Tiene un identificador único (id).
 * Tiene una posición inicial y una posición actual en la ruta.
 * Tiene un color.
 * Se representa visualmente con un Circle en el Canvas.
 *
 * Requisitos relacionados:
 * Adicionar o eliminar robots
 * Retornar robots a su posición inicial
 * Mover un robot
 *
 * @author
 *Camilo Aguirre - Mateo Sanchez
 * @version 28-09-2025
 */
public class Robot {
    private int id;
    private int initialLocation; 
    private int currentLocation;  
    private String colorName;
    private Circle circle;   
    private int position;
    private int totalProfit;
    private String type;
    private int money;
    public ArrayList<Integer> profitsPerMove = new ArrayList<>();
    
    /**
     * Crea un robot sin especificar color (se asignará automáticamente).
     *
     * @param id         Identificador único del robot
     * @param location   Posición inicial del robot en la ruta
     */
    public Robot(int id, int location) {
        this.id = id;
        initialLocation = location;
        currentLocation = location;
        this.colorName = null;  // Se asignará automáticamente en SilkRoad
        type = "normal";
        money = 0;
        circle = null;
    }
    
    /**
     * Crea un nuevo robot en la posición indicada.
     *
     * @param id         Identificador único del robot
     * @param location   Posición inicial del robot en la ruta
     * @param colorName  Color del robot ("red", "blue", "green", etc.)
     */
    public Robot(int id, int location, String colorName) {
        this.id = id;
        initialLocation = location;
        currentLocation = location;
        this.colorName = colorName;
        type = "normal";
        money = 0;
        circle = null;
    }
    
    /**
     * Crea un robot con tipo específico.
     *
     * @param id         Identificador único del robot
     * @param location   Posición inicial del robot
     * @param colorName  Color del robot
     * @param type       Tipo de robot ("normal", "neverback", "tender", "dummy")
     */
    public Robot(int id, int location, String colorName, String type) {
        this.id = id;
        initialLocation = location;
        currentLocation = location;
        this.colorName = colorName;
        this.type = type;
        money = 0;
        circle = null;
    }
    /** Devuelve la ganancia total acumulada por el robot */
    public int getTotalProfit() {
        return totalProfit;
    }
    
    /** Devuelve la lista con las ganancias o pérdidas de cada movimiento.*/
    public ArrayList<Integer> getProfitsPerMove() {
        return profitsPerMove;
    }
    
    /** Devuelve la posición actual del jugador o robot.*/
    public int getPosition() { 
        return position; 
    }
    
    /** Cambia la posición actual y mueve al jugador o robot al nuevo lugar.*/
    public void moveTo(int pos) { 
        position = pos;
    }
    
    /** Suma la nueva ganancia o pérdida al total
     * y la guarda en la lista de ganancias por movimiento.*/
    public void addProfit(int gain) {
        totalProfit = totalProfit + gain;
        profitsPerMove.add(gain);
    }

    /**Obtiene el identificador único del robot. */
    public int getId() {
        return id; 
    }

    /** Consulta la ubicación actual del robot en la ruta.*/
    public int getLocation() { 
        return currentLocation; 
    }

    /**Consulta la ubicación inicial del robot. */
    public int getInitialLocation() { 
        return initialLocation;     
    }

    /** Obtiene el nombre del color asignado al robot.*/
    public String getColorName() { 
        return colorName; 
    }
    
    /** 
     * Devuelve el tipo de robot.
     * 
     * @return Tipo actual del robot ("normal", "neverback", "tender" o "dummy").
     */
    public String getType() {
        return type;
    }
    
    /**
     * Devuelve la cantidad actual de dinero que posee el robot.
     * 
     * @return Cantidad total de dinero acumulado por el robot.
     */
    public int getMoney() {
        return money;
    }
    
    /**
     * Aumenta la cantidad de dinero del robot.
     * 
     * @param amount Cantidad de dinero a sumar al total del robot.
     */
    public void addMoney(int amount) {
        money = money + amount;
    }
    
    /**
     * Resta una cantidad de dinero al robot (por ejemplo, en una tienda trampa).
     * 
     * Si el resultado es negativo, el dinero se ajusta automáticamente a cero.
     * 
     * @param amount Cantidad de dinero a restar.
     */
    public void subtractMoney(int amount) {
        money = money - amount;
        if (money < 0) {
            money = 0;
        }
    }

    /**
     * Mueve el robot a una nueva ubicación dentro de la ruta de la seda.
     * 
     * @param newLocation Nueva posición de destino en la ruta.
     */
    public void moveToLocation(int newLocation) {
        currentLocation = newLocation;
    }

    /** Retorna el robot a su posición inicial. */
    public void reset() {
        currentLocation = this.initialLocation;
    }

    /**
     * Asigna una figura gráfica (Circle) al robot para su representación visual.
     * 
     * @param c Figura Circle que representa gráficamente al robot.
     */
    public void setCircle(Circle c) {
        this.circle = c;
    }

    /** Obtiene la figura (Circle) del robot; puede ser null si no está visible. */
    public Circle getCircle() {
        return circle;
    }

    /**
     * Configura tamaño, posición y visibilidad de la figura ya asociada.
     * @param x         coordenada X 
     * @param y         coordenada Y 
     * @param diameter  diámetro del círculo en píxeles
     * @param visible   si es true, hace visible la figura
     */
    public void drawAt(int x, int y, int diameter, boolean visible) {
        if (circle == null) {
            return;
        }

        circle.changeColor(colorName);
        circle.changeSize(diameter);
        circle.moveTo(x, y);

        if (visible) {
            circle.makeVisible();
        } else {
            circle.makeInvisible();
        }
    }

    /** 
     * Muestra u oculta la figura asociada. 
     * 
     * @param v True para hacerlo visible, False para ocultarlo.
     */
    public void setVisible(boolean v) {
        if (circle == null) {
            return;
        }
    
        if (v) {
            circle.makeVisible();
        } else {
            circle.makeInvisible();
        }
    }

   /**
     * Cambia el color del robot (y de su figura si está visible).
     * 
     * @param newColor Nuevo color como texto ("red", "blue", "green", etc.).
     */
    public void setColor(String newColor) {
        this.colorName = newColor;
        if (circle != null) {
            circle.changeColor(newColor);
        }
    }

    /**
     * Libera los recursos visuales del robot.
     * 
     * Oculta el círculo del canvas y elimina su referencia visual.
     */
    public void disposeView() {
        if (circle != null) {
            circle.makeInvisible();
            circle = null;
        }
    }
}