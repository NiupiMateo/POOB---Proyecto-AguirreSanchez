package silkRoad;

/**
 * Clase creada para calcular coordenadas en una espiral cuadrada
 * de forma incremental  
 * @author Camilo Aguirre- Mateo Sanchez
 * @version 28-09-2025
 */
public class Spiral {

    /**
     * Retorna las coordenadas (x,y) de la posición n en la espiral.
     * 
     * - La celda 1 está en (0,0).
     * - Luego se avanza derecha, arriba, izquierda, abajo
     *   aumentando el tamaño de los pasos cada 2 giros.
     *
     * @param n número de la celda (1 = centro)
     * @return arreglo [x,y] con las coordenadas
     */
    public static int[] getCoords(int n) {
        if (n <= 1) {
            return new int[]{0, 0};
        }

        int x = 0, y = 0;   // posición actual
        int steps = 1;   // cuántos pasos dar en cada dirección
        int count = 1;      // cuántas celdas llevamos
        int dir = 0;        // 0=derecha, 1=arriba, 2=izquierda, 3=abajo

        // Avanzamos hasta llegar a la celda n
        while (count < n) {
            for (int repeat = 0; repeat < 2; repeat++) { // dos direcciones con mismo steps
                for (int i = 0; i < steps && count < n; i++) {
                    switch (dir) {
                        case 0: x++; 
                        break; // derecha
                        case 1: y++; 
                        break; // arriba
                        case 2: x--; 
                        break; // izquierda
                        case 3: y--; 
                        break; // abajo
                    }
                    count++;
                    if (count == n) {
                        return new int[]{x, y};
                    }
                }
                dir = (dir + 1) % 4; // cambiar dirección
            }
            steps++; // después de dos direcciones, incrementa el paso
        }

        return new int[]{x, y};
    }
}
