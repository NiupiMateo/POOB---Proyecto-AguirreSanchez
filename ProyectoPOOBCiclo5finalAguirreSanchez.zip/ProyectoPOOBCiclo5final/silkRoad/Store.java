package silkRoad;

import shapes.Rectangle;

/**
 * Representa una tienda dentro del simulador de la Ruta de la Seda.
 *
 * Cada tienda:
 * - Tiene un identificador único.
 * - Tiene una ubicación en la ruta.
 * - Almacena una cierta cantidad de tenges.
 * - Tiene un color único.
 * - Puede representarse visualmente con un Rectangle en el Canvas.
 *
 * Requisitos relacionados:
 * - Adicionar o eliminar una tienda
 * - Reabastecer todas las tiendas
 * - Reiniciar la ruta con las tiendas en estado inicial
 * 
 * @author 
 * Camilo Aguirre - Mateo Sanchez
 * @version 28-09-2025
 */
public class Store {
    private int id;
    private int location;     
    private int tenges;
    private int initialTenges;
    private String colorName;
    private int timesEmptied = 0;
    private String type;
    private double trapFactor;
    private Rectangle rectangle; 

    /**
     * Crea una tienda sin especificar color (se asignará automáticamente).
     *
     * @param id         Identificador único de la tienda.
     * @param location   Posición en la ruta.
     * @param tenges     Cantidad inicial de tenges.
     */
    public Store(int id, int location, int tenges) {
        this.id = id;
        this.location = location;
        this.tenges = tenges;
        initialTenges = tenges;
        this.colorName = null;  // Se asignará automáticamente en SilkRoad
        type = "normal";
        trapFactor = 0.2;
        rectangle = null; 
    }
    
    /**
     * Crea una tienda en la ubicación dada, con la cantidad inicial de tenges.
     *
     * @param id         Identificador único de la tienda.
     * @param location   Posición en la ruta.
     * @param tenges     Cantidad inicial de tenges.
     * @param colorName  Color de la tienda ("red", "blue", etc.).
     */
    public Store(int id, int location, int tenges, String colorName) {
        this.id = id;
        this.location = location;
        this.tenges = tenges;
        initialTenges = tenges;
        this.colorName = colorName;
        type = "normal";
        trapFactor = 0.2;
        rectangle = null; 
    }
    
    /**
     * Crea una tienda con tipo específico.
     *
     * @param id         Identificador único de la tienda.
     * @param location   Posición en la ruta.
     * @param tenges     Cantidad inicial de tenges.
     * @param colorName  Color de la tienda.
     * @param type       Tipo de tienda ("normal", "autonomous", "fighter", "trap").
     */
    public Store(int id, int location, int tenges, String colorName, String type) {
        this.id = id;
        this.location = location;
        this.tenges = tenges;
        initialTenges = tenges;
        this.colorName = colorName;
        this.type = type;
        trapFactor = 0.2;
        rectangle = null; 
    }
    
    /**
     * Actualiza la apariencia visual de la tienda dependiendo si está vacía o no.
     * Si está vacía, cambia el color a gris; si no, conserva su color original.
     */
    public void updateAppearance() {
        if (rectangle == null) return;
    
        if (isEmpty()) {
            rectangle.changeColor("gray");
        } else {
            rectangle.changeColor(colorName);
        }
        rectangle.makeInvisible();
        rectangle.makeVisible();
    }

    /** Vacía completamente la tienda y aumenta el contador de veces vaciada. */
    public void empty() {
        if (tenges > 0) {
            tenges = 0;
            timesEmptied++;
            updateAppearance(); 
        }
    }

    /** Devuelve cuántas veces ha sido vaciada la tienda. */
    public int getTimesEmptied() {
        return timesEmptied;
    }

    /** Devuelve el identificador único del objeto. */
    public int getId() {
        return id; 
    }

    /** Devuelve la ubicación actual del objeto dentro de la ruta o tablero. */
    public int getLocation() { 
        return location; 
    }

    /** Devuelve la cantidad actual de tenges que posee el objeto. */
    public int getTenges() { 
        return tenges; 
    }

    /** Devuelve el nombre del color asignado al objeto. */
    public String getColorName() { 
        return colorName; 
    }
    
    /**
     * Devuelve el tipo de tienda.
     *
     * @return Tipo de tienda actual ("normal", "autonomous", "fighter" o "trap").
     */
    public String getType() {
        return type;
    }
    
    /**
     * Devuelve el factor de trampa de la tienda.
     *
     * Este valor representa el porcentaje de dinero que un robot pierde al visitar
     * una tienda tipo "trap".
     *
     * @return Factor de trampa como número decimal (ejemplo: 0.2 equivale al 20%).
     */
    public double getTrapFactor() {
        return trapFactor;
    }
    
    /** 
     * Reabastece la tienda con la cantidad de tenges inicial definida
     * al momento de su creación. 
     */
    public void resupply() {
        tenges = initialTenges;
    }

    /** @return true si la tienda ya no tiene tenges. */
    public boolean isEmpty() {
        return tenges <= 0;
    }

    /**
     * Retira una cantidad de dinero de la tienda.
     * Si la cantidad solicitada supera el dinero disponible, retira solo lo posible.
     *
     * @param amount Cantidad solicitada de tenges.
     * @return Cantidad efectivamente retirada de la tienda.
     */
    public int withdraw(int amount) {
        int taken = Math.max(0, Math.min(amount, tenges));
        tenges = tenges - taken;
        return taken;
    }

    /** Asigna el rectángulo que representa visualmente a la tienda. */
    public void setRectangle(Rectangle r) {
        this.rectangle = r;
    }

    /** Devuelve la figura Rectangle asociada (puede ser null si no está visible). */
    public Rectangle getRectangle() {
        return rectangle;
    }

    /**
     * Dibuja o reposiciona la figura de la tienda (Rectangle) en el canvas.
     *
     * @param x Coordenada X donde se ubicará la figura.
     * @param y Coordenada Y donde se ubicará la figura.
     * @param widthPx Ancho del rectángulo en píxeles.
     * @param heightPx Alto del rectángulo en píxeles.
     * @param visible True si debe hacerse visible en pantalla.
     */
    public void mountAt(int x, int y, int widthPx, int heightPx, boolean visible) {
        if (rectangle == null) 
            return;

        rectangle.changeColor(colorName);
        rectangle.changeSize(heightPx, widthPx);
        rectangle.moveTo(x, y);

        if (visible) 
            rectangle.makeVisible();
        else 
            rectangle.makeInvisible();
    }

    /**
     * Muestra u oculta visualmente la figura asociada a la tienda.
     *
     * @param v True para hacerla visible, False para ocultarla.
     */
    public void setVisible(boolean v) {
        if (rectangle == null) 
            return;

        if (v) 
            rectangle.makeVisible();
        else
            rectangle.makeInvisible();
    }

    /**
     * Cambia el color asignado a la tienda y actualiza su figura visual.
     *
     * @param newColor Nuevo color a aplicar (por ejemplo: "red", "blue", "green").
     */
    public void setColor(String newColor) {
        colorName = newColor;
        if (rectangle != null) 
            rectangle.changeColor(newColor);
    }

    /**
     * Libera los recursos gráficos asociados a la tienda.
     *
     * Oculta la figura Rectangle en el canvas y elimina su referencia
     * para permitir una limpieza completa del simulador.
     */
    public void disposeView() {
        if (rectangle != null) {
            rectangle.makeInvisible();
            rectangle = null;
        }
    }
}