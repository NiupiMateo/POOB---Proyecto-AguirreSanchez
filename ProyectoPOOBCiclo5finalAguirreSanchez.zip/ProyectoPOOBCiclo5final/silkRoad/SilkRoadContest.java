package silkRoad;

import shapes.*;
import java.util.ArrayList;
/**
 * Clase que resuelve el problema de la maratón "The Silk Road ... with Robots!"
 * y permite simularlo visualmente usando la clase SilkRoad.
 * 
 * @author Camilo Aguirre - Mateo Sanchez
 * @version 05-10-2025
 */
public class SilkRoadContest {
    /**
     * Resuelve el problema de la maratón:
     * Dada la secuencia de días, calcula la ganancia máxima total
     * alcanzable después de cada día.
     *
     * @param days matriz de enteros con los datos de entrada:
     *             [1, x]   → agregar robot en posición x
     *             [2, x, c] → agregar tienda en posición x con c tenges
     * @return arreglo con las ganancias máximas acumuladas tras cada día
     */
    public int[] solve(int[][] days) {
        ArrayList<Integer> robots = new ArrayList<>();
        ArrayList<Store> stores = new ArrayList<>();
        int[] result = new int[days.length];

        for (int i = 0; i < days.length; i++) {
            int type = days[i][0];
            int pos = days[i][1];

            if (type == 1) {
                robots.add(pos);
            } else if (type == 2) {
                int tenges = days[i][2];
                stores.add(new Store(stores.size() + 1, pos, tenges, "yellow"));
            }

            result[i] = calculateMaxProfit(robots, stores);
        }

        return result;
    }

    /**
     * Calcula la ganancia máxima posible con los robots y tiendas actuales.
     * Cada tienda busca el robot que más ganancia le genera.
     */
    private int calculateMaxProfit(ArrayList<Integer> robots, ArrayList<Store> stores) {
        if (robots.isEmpty() || stores.isEmpty()) return 0;

        int total = 0;
        for (Store s : stores) {
            int bestGain = Integer.MIN_VALUE;
            for (int r : robots) {
                int gain = s.getTenges() - Math.abs(s.getLocation() - r);
                if (gain > bestGain) bestGain = gain;
            }
            if (bestGain > 0) total += bestGain;
        }
        return total;
    }

    /**
     * Simula visualmente la solución en el entorno gráfico de SilkRoad.
     * 
     * @param days matriz de eventos del problema (igual que en solve)
     * @param slow si es true, muestra la simulación con pausas visuales
     */
    public void simulate(int[][] days, boolean slow) {
        // Crea SilkRoad usando el constructor int[][]
        SilkRoad simu = new SilkRoad(days);

        simu.moveRobots();

        if (slow) {
            Canvas canvas = Canvas.getCanvas();
            for (int i = 0; i < 3; i++) {
                simu.blinkTopRobot();
                canvas.wait(400);
            }
        }

        simu.redraw(); 
        System.out.println("Simulación completa, la ganancia total es: " + simu.profit());
    }
}
