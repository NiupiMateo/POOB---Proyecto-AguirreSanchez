package shapes;

/**
 * Clase base abstracta para todas las figuras geométricas.
 * Define los atributos y métodos comunes que todas las figuras comparten.
 * 
 * @author Camilo
 * @version 1.0 (Ciclo 4)
 */
public abstract class FiguraGeometrica {
    
    // Atributos comunes a todas las figuras
    protected int xPosition;
    protected int yPosition;
    protected String color;
    protected boolean isVisible;
    
    /**
     * Constructor de la clase FiguraGeometrica.
     */
    public FiguraGeometrica() {
        // Constructor base
    }
    
    /**
     * Hace visible esta figura. Si ya estaba visible, no hace nada.
     */
    public void makeVisible() {
        isVisible = true;
        draw();
    }
    
    /**
     * Hace invisible esta figura. Si ya estaba invisible, no hace nada.
     */
    public void makeInvisible() {
        erase();
        isVisible = false;
    }
    
    /**
     * Mueve la figura algunos píxeles a la derecha.
     */
    public void moveRight() {
        moveHorizontal(20);
    }
    
    /**
     * Mueve la figura algunos píxeles a la izquierda.
     */
    public void moveLeft() {
        moveHorizontal(-20);
    }
    
    /**
     * Mueve la figura algunos píxeles hacia arriba.
     */
    public void moveUp() {
        moveVertical(-20);
    }
    
    /**
     * Mueve la figura algunos píxeles hacia abajo.
     */
    public void moveDown() {
        moveVertical(20);
    }
    
    /**
     * Mueve la figura horizontalmente.
     * @param distance la distancia deseada en píxeles
     */
    public void moveHorizontal(int distance) {
        erase();
        xPosition += distance;
        draw();
    }
    
    /**
     * Mueve la figura verticalmente.
     * @param distance la distancia deseada en píxeles
     */
    public void moveVertical(int distance) {
        erase();
        yPosition += distance;
        draw();
    }
    
    /**
     * Cambia el color de la figura.
     * @param newColor el nuevo color. Los colores válidos son "red", "yellow", 
     * "blue", "green", "magenta" y "black".
     */
    public void changeColor(String newColor) {
        color = newColor;
        draw();
    }
    
    /**
     * Método abstracto para dibujar la figura en el canvas.
     * Cada subclase debe implementar su propia forma de dibujar.
     */
    protected abstract void draw();
    
    /**
     * Método abstracto para borrar la figura del canvas.
     * Cada subclase debe implementar su propia forma de borrar.
     */
    protected abstract void erase();
}
